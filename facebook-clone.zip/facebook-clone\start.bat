@echo off
cd /d "%~dp0"
echo Starting Facebook Clone server...
python server.py
pause