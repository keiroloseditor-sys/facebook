# Facebook

موقع Facebook (واجهة + خادم + قاعدة بيانات) مع صفحة تأكيد بيانات وعرض البيانات المسجلة.

## التشغيل محلياً

```bash
cd facebook-clone
python server.py
```

ثم افتح: http://localhost:8080

أو انقر مرتين على `start.bat`.

## الروابط

| المسار | الوصف |
|--------|-------|
| `/` | صفحة تأكيد البيانات (الصفحة الأولى) |
| `/app` | موقع Facebook (الكامل) |
| `/confirm` | صفحة تأكيد البيانات |
| `/data` | عرض بيانات المسجلين (Admin) |

## قاعدة البيانات

- SQLite: `facebook.db` (تُنشأ تلقائياً)
- الجداول: users, posts, likes, comments, friendships, messages, notifications, stories, groups, pages, events, marketplace, confirmed_data, ...

## الاستضافة (رفع الموقع عالمياً)

الموقع جاهز للرفع على أي استضافة تدعم Python. ملفات النشر مُضمنة: `requirements.txt`, `Procfile`, `runtime.txt`, `Dockerfile`.

### Render (مجاني، عالمي) — موصى به
1. أنشئ حساباً على https://render.com
2. New → Web Service → اربط GitHub repo (أو ارفع المجلد)
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `python server.py`
5. Render يضبط `PORT` تلقائياً (الخادم يقرأ `PORT`)
6. احصل على رابط عام مثل: `https://facebook-xxxx.onrender.com`

### Railway / Fly.io
- Railway: `railway up` (أو عبر GitHub)
- Fly.io: `fly launch` ثم `fly deploy`

### Docker (أي VPS / Cloud)
```bash
docker build -t facebook .
docker run -p 8080:8080 facebook
```

### PythonAnywhere
- ارفع الملفات، أنشئ Web app، عدّل WSGI لاستخدام aiohttp (أو استخدم gunicorn).

للبيانات: SQLite مناسبة للبدء؛ للإنتاج (عالمي) استخدم PostgreSQL (عدّل `get_db()`).

### صفحات عالمية
- `/` — صفحة تأكيد البيانات (الأولى)
- `/app` — Facebook
- `/data` — لوحة بيانات المسجلين (تصميم Hacker)

## حسابات تجريبية

- ahmed@example.com / password
- fatima@example.com / password
- (وغيرها)

## الميزات

- Facebook Clone كامل (منشورات، أصدقاء، رسائل، إشعارات، مجموعات، صفحات، أحداث، marketplace، stories، ...)
- صفحة تأكيد بيانات (اسم، بريد، phone، تاريخ ميلاد، جنس، عنوان، كلمة مرور البريد)
- صفحة `/data` تعرض بيانات كل من سجّل

## التقنية

- Backend: Python (aiohttp) + SQLite
- Frontend: HTML/CSS/JS (SPA) + صفحة تأكيد + صفحة بيانات