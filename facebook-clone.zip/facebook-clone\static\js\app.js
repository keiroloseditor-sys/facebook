// ===== Facebook Clone SPA (full) =====
const API = {
  async req(path, opts = {}) {
    const res = await fetch(path, { credentials: "include", ...opts });
    let data = {};
    try { data = await res.json(); } catch(e) {}
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
  },
  get: (p) => API.req(p),
  post: (p, body) => API.req(p, { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(body) }),
  put: (p, body) => API.req(p, { method: "PUT", headers: {"Content-Type":"application/json"}, body: JSON.stringify(body) }),
  del: (p) => API.req(p, { method: "DELETE" }),
  uploadPost: async (content, file, extra={}) => {
    const fd = new FormData();
    fd.append("content", content);
    if (file) fd.append("image", file);
    for (const k in extra) fd.append(k, extra[k]);
    const res = await fetch("/api/posts", { method: "POST", credentials: "include", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
  },
  upload: async (p, file, fields={}) => {
    const fd = new FormData();
    fd.append("file", file);
    for (const k in fields) fd.append(k, fields[k]);
    const res = await fetch(p, { method: "POST", credentials: "include", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
  }
};

const REACTIONS = [
  { key: "like", emoji: "👍", label: "إعجاب", color: "#1877F2" },
  { key: "love", emoji: "❤️", label: "أحببته", color: "#F33E58" },
  { key: "haha", emoji: "😂", label: "هاها", color: "#F7B125" },
  { key: "wow", emoji: "😮", label: "واو", color: "#F7B125" },
  { key: "sad", emoji: "😢", label: "أحزنني", color: "#F7B125" },
  { key: "angry", emoji: "😡", label: "أغضبني", color: "#E9710F" },
];

const ICONS = {
  home: '<path d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"/>',
  friends: '<path d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/>',
  watch: '<path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/><path d="M15.91 11.672a.375.375 0 010 .656l-5.603 3.113a.375.375 0 01-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112z"/>',
  marketplace: '<path d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/>',
  groups: '<path d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z"/>',
  menu: '<path d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"/>',
  messenger: '<path d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z"/>',
  bell: '<path d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"/>',
  search: '<path d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"/>',
  plus: '<path d="M12 4.5v15m7.5-7.5h-15"/>',
  image: '<path d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"/>',
  video: '<path d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z"/>',
  smile: '<path d="M15.182 15.182a4.5 4.5 0 01-6.364 0M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.008H9.375V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.008h-.008V9.75z"/>',
  comment: '<path d="M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.076-4.076a1.526 1.526 0 011.037-.443 48.282 48.282 0 005.68-.494c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z"/>',
  share: '<path d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 103.935 2.186 2.25 2.25 0 00-3.935-2.186zm0-12.814a2.25 2.25 0 103.933-2.185 2.25 2.25 0 00-3.933 2.185z"/>',
  bookmark: '<path d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z"/>',
  more: '<path d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/>',
  close: '<path d="M6 18L18 6M6 6l12 12"/>',
  edit: '<path d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"/>',
  trash: '<path d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"/>',
  clock: '<path d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"/>',
  location: '<path d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"/><path d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"/>',
  phone: '<path d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"/>',
  globe: '<path d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418"/>',
  cake: '<path d="M21 15a2 2 0 01-2 2H5a2 2 0 01-2-2V9a2 2 0 012-2h14a2 2 0 012 2v6zM9 3v4M15 3v4M9 15h6"/>',
  heart: '<path d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"/>',
  user: '<path d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"/>',
  gear: '<path d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281zM15 12a3 3 0 11-6 0 3 3 0 016 0z"/>',
  logout: '<path d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9"/>',
  calendar: '<path d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"/>',
  tag: '<path d="M9.568 3H5.25A2.25 2.25 0 003 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.365a18.061 18.061 0 005.08-4.06 1.728 1.728 0 00-.364-2.606L10.96 3.66A2.25 2.25 0 009.568 3z"/><path d="M6 6h.008v.008H6V6z"/>',
  camera: '<path d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a48.329 48.329 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z"/><path d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z"/>',
  check: '<path d="M4.5 12.75l6 6 9-13.5"/>',
  link: '<path d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244"/>',
};
function svgIcon(name, size) {
  size = size || 20;
  const d = ICONS[name];
  if (!d) return '';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;">${d}</svg>`;
}
function I(name, size) { return el('span', { html: svgIcon(name, size||20), style: "display:inline-flex;align-items:center;" }); }

const state = {
  user: null,
  view: "feed",
  params: {},
  notifOpen: false,
  chatPartner: null,
  theme: "light",
  feedOffset: 0,
  feedTotal: 0,
  feedLoading: false,
  selectedReactionPost: null,
};

function $(sel, root=document) { return root.querySelector(sel); }
function $$(sel, root=document) { return [...root.querySelectorAll(sel)]; }
function el(tag, attrs={}, children=[]) {
  const e = document.createElement(tag);
  for (const k in attrs) {
    if (k === "class") e.className = attrs[k];
    else if (k === "html") e.innerHTML = attrs[k];
    else if (k.startsWith("on")) e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
    else if (k === "style" && typeof attrs[k]==="object") Object.assign(e.style, attrs[k]);
    else e.setAttribute(k, attrs[k]);
  }
  for (const c of children) {
    if (c == null) continue;
    e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return e;
}
function avatarUrl(u) {
  if (!u) return "https://ui-avatars.com/api/?name=User&background=1877F2&color=fff&size=200";
  if (u.avatar_url) return u.avatar_url;
  return "https://ui-avatars.com/api/?name=" + encodeURIComponent(u.name||"User") + "&background=1877F2&color=fff&size=200";
}
function timeAgo(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const diff = (Date.now() - d.getTime())/1000;
  if (diff < 60) return "الآن";
  if (diff < 3600) return Math.floor(diff/60) + " د";
  if (diff < 86400) return Math.floor(diff/3600) + " س";
  if (diff < 604800) return Math.floor(diff/86400) + " ي";
  return d.toLocaleDateString("ar");
}
function toast(msg) {
  const t = el("div", { class: "toast" }, [msg]);
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}
function reactionInfo(key) { return REACTIONS.find(r=>r.key===key) || REACTIONS[0]; }

// ===== Auth =====
async function loadMe() {
  try {
    const d = await API.get("/api/me");
    state.user = d.user;
    if (d.user) {
      state.theme = d.user.theme || "light";
      applyTheme(state.theme);
    }
  } catch(e) { state.user = null; }
}
function applyTheme(t) {
  state.theme = t;
  if (t === "dark") document.body.classList.add("dark");
  else document.body.classList.remove("dark");
}

function renderAuth(mode="login") {
  const app = $("#app");
  app.innerHTML = "";
  const box = el("div", { class: "auth-page" }, [
    el("div", { class: "auth-box" }, [
      el("div", { class: "auth-logo" }, ["f"]),
      el("div", { class: "auth-sub" }, [mode==="login" ? "تسجيل الدخول إلى Facebook" : "إنشاء حساب جديد"]),
      el("div", { id: "auth-error", class: "auth-error" }),
      ...(mode==="login" ? [
        el("input", { class: "auth-input", id: "email", type: "email", placeholder: "البريد الإلكتروني أو رقم الهاتف" }),
        el("input", { class: "auth-input", id: "password", type: "password", placeholder: "كلمة المرور" }),
        el("button", { class: "auth-btn", onclick: doLogin }, ["تسجيل الدخول"]),
        el("div", { class: "auth-link", onclick: () => renderAuth("register") }, ["إنشاء حساب جديد"]),
      ] : [
        el("input", { class: "auth-input", id: "name", placeholder: "الاسم completo" }),
        el("input", { class: "auth-input", id: "email", type: "email", placeholder: "البريد الإلكتروني" }),
        el("input", { class: "auth-input", id: "password", type: "password", placeholder: "كلمة المرور (4+ أحرف)" }),
        el("input", { class: "auth-input", id: "birthday", type: "date", placeholder: "تاريخ الميلاد" }),
        el("select", { class: "auth-input", id: "gender" }, [
          el("option", { value: "" }, ["الجنس"]),
          el("option", { value: "male" }, ["ذكر"]),
          el("option", { value: "female" }, ["أنثى"]),
        ]),
        el("button", { class: "auth-btn green", onclick: doRegister }, ["تسجيل"]),
        el("div", { class: "auth-link", onclick: () => renderAuth("login") }, ["لديك حساب بالفعل؟"]),
      ]),
      el("div", { class: "auth-divider" }),
      el("div", { style: "text-align:center;font-size:13px;color:#65676B;" }, ["حسابات تجريبية: ahmed@example.com / password"]),
    ])
  ]);
  app.appendChild(box);
}
async function doLogin() {
  const email = $("#email").value;
  const password = $("#password").value;
  try {
    const d = await API.post("/api/login", { email, password });
    state.user = d.user;
    if (d.user.theme) applyTheme(d.user.theme);
    navigate("feed");
  } catch(e) { $("#auth-error").textContent = e.message; }
}
async function doRegister() {
  const name = $("#name").value;
  const email = $("#email").value;
  const password = $("#password").value;
  const birthday = $("#birthday").value;
  const gender = $("#gender").value;
  try {
    const d = await API.post("/api/register", { name, email, password });
    state.user = d.user;
    await API.put("/api/settings", { birthday, gender });
    if (d.user.theme) applyTheme(d.user.theme);
    navigate("feed");
  } catch(e) { $("#auth-error").textContent = e.message; }
}
async function doLogout() {
  await API.post("/api/logout");
  state.user = null;
  renderAuth("login");
}

// ===== Navigation =====
function navigate(view, params={}) {
  state.view = view;
  state.params = params;
  const hash = view + (params && Object.keys(params).length ? "?" + new URLSearchParams(params).toString() : "");
  if (location.hash.slice(1) !== hash) location.hash = hash;
  render();
}
window.addEventListener("hashchange", () => {
  const h = location.hash.slice(1) || "feed";
  const [view, qs] = h.split("?");
  state.view = view || "feed";
  state.params = qs ? Object.fromEntries(new URLSearchParams(qs)) : {};
  render();
});

// ===== Topbar =====
function renderTopbar() {
  const tb = el("div", { class: "topbar" });
  const left = el("div", { class: "topbar-left" }, [
    el("div", { class: "logo", onclick: () => navigate("feed") }, ["f"]),
    el("div", { class: "search-box" }, [
      el("span", { class: "icon" }, [I("search", 18)]),
      el("input", { placeholder: "بحث في Facebook", onkeydown: (e) => { if(e.key==="Enter" && e.target.value.trim()) navigate("search", {q: e.target.value}); } }),
    ]),
  ]);
  const center = el("div", { class: "topbar-center" }, [
    navButton(I("home", 26), "feed", "الصفحة الرئيسية"),
    navButton(I("watch", 26), "watch", "Watch"),
    navButton(I("marketplace", 26), "marketplace", "Marketplace"),
    navButton(I("groups", 26), "groups", "المجموعات"),
    navButton(I("friends", 26), "friends", "الأصدقاء"),
  ]);
  const right = el("div", { class: "topbar-right" }, [
    el("div", { class: "icon-btn", title: "القائمة", onclick: () => navigate("menu") }, [I("menu", 20)]),
    el("div", { class: "icon-btn", title: "Messenger", onclick: () => navigate("messages") }, [I("messenger", 20)]),
    el("div", { class: "icon-btn", title: "الإشعارات", onclick: toggleNotif, id: "notif-btn" }, [
      I("bell", 20),
      el("span", { class: "badge", id: "notif-badge", style: "display:none;" }, ["0"]),
    ]),
    el("img", { class: "avatar-sm", src: avatarUrl(state.user), onclick: () => navigate("profile", {id: state.user.id}) }),
  ]);
  tb.appendChild(left); tb.appendChild(center); tb.appendChild(right);
  return tb;
}
function navButton(icon, view, title) {
  return el("div", { class: "nav-btn" + (state.view===view ? " active" : ""), title, onclick: () => navigate(view) }, [icon]);
}

// ===== Sidebar =====
function renderSidebar() {
  const sb = el("div", { class: "sidebar" });
  const me = state.user;
  sb.appendChild(el("div", { class: "sidebar-item", onclick: () => navigate("profile", {id: me.id}) }, [
    el("img", { src: avatarUrl(me) }), el("span", {}, [me.name]),
  ]));
  const items = [
    [I("friends", 20),"الأصدقاء","friends"],
    [I("watch", 20),"Watch","watch"],
    [I("marketplace", 20),"Marketplace","marketplace"],
    [I("groups", 20),"المجموعات","groups"],
    [I("clock", 20),"الذكريات","memories"],
    [I("bookmark", 20),"المحفوظات","saved"],
    [I("globe", 20),"الصفحات","pages"],
    [I("calendar", 20),"الأحداث","events"],
    [I("gear", 20),"الإعدادات","settings"],
  ];
  for (const [ico,label,view] of items) {
    sb.appendChild(el("div", { class: "sidebar-item", onclick: () => navigate(view) }, [
      el("div", { class: "ico" }, [ico]), el("span", {}, [label]),
    ]));
  }
  sb.appendChild(el("div", { class: "sidebar-section" }));
  sb.appendChild(el("div", { class: "sidebar-title" }, ["اختصاراتك"]));
  sb.appendChild(el("div", { class: "sidebar-item" }, [I("groups", 20), el("span",{},["مجموعة التقنية"])]));
  sb.appendChild(el("div", { class: "sidebar-section" }));
  sb.appendChild(el("div", { class: "sidebar-item", onclick: doLogout }, [I("logout", 20), el("span",{},["تسجيل الخروج"])]));
  return sb;
}

// ===== Rightbar =====
function renderRightbar() {
  const rb = el("div", { class: "rightbar" });
  rb.appendChild(el("div", { class: "rightbar-title" }, ["المدعوم"]));
  rb.appendChild(el("div", { class: "sponsored" }, [
    el("img", { src: "https://picsum.photos/seed/ad1/200/120" }),
    el("div", {}, [el("div", {style:"font-weight:600;font-size:14px;"}, ["اشترِ iPhone 15 Pro"]), el("div", {style:"color:#65676B;font-size:12px;"}, ["apple.com"])]),
  ]));
  rb.appendChild(el("div", { class: "rightbar-title" }, ["أعياد ميلاد"]));
  rb.appendChild(el("div", { style: "padding:8px;font-size:14px;" }, ["🎂 عيد ميلاد سارة اليوم"]));
  rb.appendChild(el("div", { class: "rightbar-title" }, ["قد تعرف"]));
  const suggestions = el("div", { id: "suggestions" });
  rb.appendChild(suggestions);
  loadSuggestions(suggestions);
  rb.appendChild(el("div", { class: "rightbar-title" }, ["جهات الاتصال"]));
  const contacts = el("div", { id: "contacts" });
  rb.appendChild(contacts);
  loadContacts(contacts);
  return rb;
}
async function loadSuggestions(container) {
  try {
    const [fr, su] = await Promise.all([API.get("/api/friends"), API.get("/api/users/search?q=")]);
    container.innerHTML = "";
    const friendIds = new Set(fr.friends.map(f=>f.id));
    const sug = su.users.filter(u=>!friendIds.has(u.id)).slice(0,5);
    for (const u of sug) {
      const item = el("div", { class: "contact-item" }, [
        el("img", { src: avatarUrl(u) }),
        el("div", { style: "flex:1;" }, [el("div", {style:"font-weight:600;font-size:14px;"},[u.name]), el("div",{style:"color:#65676B;font-size:12px;"},["اقتراح"])]),
        el("button", { class: "btn btn-primary", style: "padding:4px 8px;font-size:12px;", onclick: async () => { await API.post("/api/friends/request",{userId:u.id}); toast("تم إرسال الطلب"); item.remove(); } }, ["+追加".replace("追加","إضافة")]),
      ]);
      container.appendChild(item);
    }
  } catch(e) {}
}
async function loadContacts(container) {
  try {
    const d = await API.get("/api/friends");
    container.innerHTML = "";
    for (const f of d.friends.slice(0,15)) {
      const item = el("div", { class: "contact-item", onclick: () => navigate("messages", {id: f.id}) }, [
        el("div", { style: "position:relative;" }, [
          el("img", { src: avatarUrl(f) }),
          el("span", { class: "online-dot" }),
        ]),
        el("span", {}, [f.name]),
      ]);
      container.appendChild(item);
    }
  } catch(e) {}
}

// ===== Main render =====
function render() {
  if (!state.user) { renderAuth("login"); return; }
  const app = $("#app");
  app.innerHTML = "";
  app.appendChild(renderTopbar());
  const layout = el("div", { class: "layout" });
  layout.appendChild(renderSidebar());
  const main = el("div", { class: "main", id: "main" });
  layout.appendChild(main);
  layout.appendChild(renderRightbar());
  app.appendChild(layout);
  renderView(main);
}
function renderView(main) {
  const v = state.view;
  main.innerHTML = '<div class="spinner"></div>';
  const map = {
    feed: renderFeed,
    profile: () => renderProfile(main, state.params.id),
    friends: () => renderFriends(main),
    messages: () => renderMessages(main, state.params.id),
    search: () => renderSearch(main, state.params.q),
    settings: () => renderSettings(main),
    memories: () => renderMemories(main),
    saved: () => renderSaved(main),
    groups: () => renderGroups(main),
    group: () => renderGroupDetail(main, state.params.id),
    pages: () => renderPages(main),
    page: () => renderPageDetail(main, state.params.id),
    events: () => renderEvents(main),
    event: () => renderEventDetail(main, state.params.id),
    marketplace: () => renderMarketplace(main),
    listing: () => renderListingDetail(main, state.params.id),
    watch: (m) => renderPlaceholder(m, "watch"),
    menu: (m) => renderPlaceholder(m, "menu"),
  };
  if (map[v]) {
    if (v === "feed") renderFeed(main);
    else map[v]();
  } else renderFeed(main);
}
function renderPlaceholder(main, v) {
  const labels = { watch:"Watch", marketplace:"Marketplace", groups:"المجموعات", menu:"القائمة" };
  main.innerHTML = "";
  main.appendChild(el("div", { class: "empty" }, [(labels[v]||v) + " — قريباً"]));
}

// ===== Stories bar =====
function renderStories(container) {
  const stories = el("div", { class: "stories" });
  // create story
  const create = el("div", { class: "story create", onclick: openCreateStory }, [
    el("div", { class: "story-top" }),
    el("div", { class: "plus" }, ["+"]),
    el("div", { class: "story-bottom" }, ["إنشاء story"]),
  ]);
  stories.appendChild(create);
  // load stories
  API.get("/api/stories").then(d => {
    for (const g of d.story_groups) {
      const u = g.user;
      const first = g.stories[0];
      const s = el("div", { class: "story", style: `background-image:url(${first.media_url || 'https://picsum.photos/seed/'+u.id+'/200/400'})`, onclick: () => openStoryViewer(g) }, [
        el("img", { class: "story-avatar", src: avatarUrl(u) }),
        el("div", { class: "story-name" }, [u.name.split(" ")[0]]),
      ]);
      if (g.stories.every(x=>x.viewed)) s.style.opacity = "0.6";
      stories.appendChild(s);
    }
  }).catch(()=>{});
  return stories;
}
function openCreateStory() {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["إنشاء Story"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  let file = null;
  const preview = el("div", { id: "story-preview", style: "margin:8px 0;" });
  const fileInput = el("input", { type: "file", accept: "image/*,video/*", style: "display:none;", onchange: (e) => {
    const f = e.target.files[0];
    if (f) { file = f; preview.innerHTML = ""; const img = el("img", { src: URL.createObjectURL(f), style: "max-width:100%;border-radius:8px;" }); preview.appendChild(img); }
  }});
  body.appendChild(el("div", { style: "display:flex;align-items:center;gap:8px;padding:8px;border:1px solid #DADDE1;border-radius:8px;cursor:pointer;", onclick: () => fileInput.click() }, [
    el("span", { style: "color:#45BD62;" }, [I("image",20)]), el("span", { style: "font-weight:600;" }, ["صورة/فيديو"]),
  ]));
  body.appendChild(fileInput);
  body.appendChild(preview);
  const textInput = el("input", { class: "auth-input", placeholder: "نص (اختياري)", id: "story-text" });
  body.appendChild(textInput);
  const colorInput = el("input", { class: "auth-input", type: "color", value: "#1877F2", id: "story-color" });
  body.appendChild(el("label", { style: "font-size:13px;color:#65676B;" }, ["لون الخلفية"]));
  body.appendChild(colorInput);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      const fd = new FormData();
      if (file) fd.append("file", file);
      fd.append("text", textInput.value);
      fd.append("bg_color", colorInput.value);
      const res = await fetch("/api/stories", { method: "POST", credentials: "include", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      overlay.remove();
      toast("تم إنشاء Story");
      render();
    } catch(e) { toast(e.message); }
  }}, ["نشر"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}
function openStoryViewer(group) {
  let idx = 0;
  const viewer = el("div", { class: "story-viewer" });
  const progress = el("div", { class: "story-progress" }, [el("div", { class: "story-progress-bar", id: "sp-bar" })]);
  viewer.appendChild(progress);
  const userRow = el("div", { class: "story-user" }, [
    el("img", { src: avatarUrl(group.user), style: "width:40px;height:40px;border-radius:50%;border:2px solid #fff;" }),
    el("span", { style: "font-weight:600;" }, [group.user.name]),
  ]);
  viewer.appendChild(userRow);
  viewer.appendChild(el("div", { class: "story-close", onclick: () => viewer.remove() }, ["✕"]));
  const mediaWrap = el("div", {}, []);
  viewer.appendChild(mediaWrap);
  document.body.appendChild(viewer);
  function show() {
    const s = group.stories[idx];
    API.post(`/api/stories/${s.id}/view`).catch(()=>{});
    mediaWrap.innerHTML = "";
    if (s.media_type === "video" && s.media_url) {
      mediaWrap.appendChild(el("video", { src: s.media_url, autoplay: true, controls: false, style: "max-height:90vh;max-width:90vw;border-radius:8px;" }));
    } else if (s.media_url) {
      mediaWrap.appendChild(el("img", { src: s.media_url, style: "max-height:90vh;max-width:90vw;border-radius:8px;" }));
    } else {
      const box = el("div", { style: `width:360px;height:640px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:${s.bg_color};color:#fff;font-size:24px;font-weight:700;text-align:center;padding:20px;` }, [s.text]);
      mediaWrap.appendChild(box);
    }
    // progress bar animate
    const bar = $("#sp-bar");
    if (bar) { bar.style.width = "0%"; let w = 0; const iv = setInterval(() => { w += 2; if (w >= 100) { clearInterval(iv); next(); } bar.style.width = w + "%"; }, 100); viewer._iv = iv; }
  }
  function next() {
    if (viewer._iv) clearInterval(viewer._iv);
    idx++;
    if (idx >= group.stories.length) { viewer.remove(); return; }
    show();
  }
  function prev() {
    if (viewer._iv) clearInterval(viewer._iv);
    idx = Math.max(0, idx-1);
    show();
  }
  viewer.addEventListener("click", (e) => {
    if (e.target.closest(".story-close")) return;
    const rect = viewer.getBoundingClientRect();
    if (e.clientX < rect.width/2) prev(); else next();
  });
  show();
}

// ===== Feed =====
async function renderFeed(main) {
  main.innerHTML = "";
  main.appendChild(renderStories());
  main.appendChild(renderCreatePost());
  const feedContainer = el("div", { id: "feed-container" });
  main.appendChild(feedContainer);
  state.feedOffset = 0;
  await loadFeedPage(feedContainer, true);
  // infinite scroll
  const sentinel = el("div", { class: "sentinel", id: "feed-sentinel" });
  main.appendChild(sentinel);
  const obs = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting && !state.feedLoading && state.feedOffset < state.feedTotal) {
      loadFeedPage(feedContainer, false);
    }
  });
  obs.observe(sentinel);
}

async function loadFeedPage(container, reset) {
  if (state.feedLoading) return;
  state.feedLoading = true;
  try {
    const d = await API.get(`/api/feed/page?offset=${state.feedOffset}&limit=10`);
    if (reset) container.innerHTML = "";
    if (!d.posts.length && reset) container.appendChild(el("div", { class: "empty" }, ["لا توجد منشورات yet."]));
    for (const p of d.posts) container.appendChild(renderPost(p));
    state.feedOffset += d.posts.length;
    state.feedTotal = d.total;
  } catch(e) { if (reset) container.appendChild(el("div", {class:"empty"},[e.message])); }
  state.feedLoading = false;
}

// ===== Create post =====
function renderCreatePost() {
  const box = el("div", { class: "create-post" });
  const top = el("div", { class: "create-post-top" }, [
    el("img", { src: avatarUrl(state.user) }),
    el("div", { class: "create-post-input", onclick: openCreatePostModal }, ["ماذا يدور في ذهنك، " + state.user.name.split(" ")[0] + "؟"]),
  ]);
  box.appendChild(top);
  const actions = el("div", { class: "create-post-actions" }, [
    el("div", { class: "create-action", onclick: openCreatePostModal }, [el("span",{style:"color:#F3425F;"},[I("video",22)]), " فيديو مباشر"]),
    el("div", { class: "create-action", onclick: openCreatePostModal }, [el("span",{style:"color:#45BD62;"},[I("image",22)]), " صورة/فيديو"]),
    el("div", { class: "create-action", onclick: openCreatePostModal }, [el("span",{style:"color:#F7B928;"},[I("smile",22)]), " شعور/نشاط"]),
  ]);
  box.appendChild(actions);
  return box;
}

let createPostFile = null;
let createPostPrivacy = "public";
let createPostFeeling = "";
let createPostLocation = "";
function openCreatePostModal() {
  createPostFile = null; createPostPrivacy = "public"; createPostFeeling = ""; createPostLocation = "";
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["إنشاء منشور"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  body.appendChild(el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:12px;" }, [
    el("img", { src: avatarUrl(state.user), style: "width:40px;height:40px;border-radius:50%;object-fit:cover;" }),
    el("div", {}, [
      el("div", { style: "font-weight:600;" }, [state.user.name]),
      el("select", { style: "font-size:12px;border:none;background:#E4E6EB;border-radius:4px;padding:2px 6px;margin-top:2px;", onchange: (e) => createPostPrivacy = e.target.value }, [
        el("option", { value: "public" }, ["🌍 للجميع"]),
        el("option", { value: "friends" }, ["👥 أصدقاء"]),
        el("option", { value: "only_me" }, ["🔒 أنا فقط"]),
      ]),
    ]),
  ]));
  const textarea = el("textarea", { id: "post-content", placeholder: "ماذا يدور في ذهنك؟", style: "width:100%;min-height:100px;border:none;outline:none;resize:none;font-size:16px;font-family:inherit;" });
  body.appendChild(textarea);
  const preview = el("div", { id: "img-preview", style: "margin-top:8px;" });
  body.appendChild(preview);
  const fileInput = el("input", { type: "file", accept: "image/*,video/*", style: "display:none;", onchange: (e) => {
    const f = e.target.files[0];
    if (f) { createPostFile = f; preview.innerHTML = ""; const img = el("img", { src: URL.createObjectURL(f), style: "max-width:100%;border-radius:8px;" }); preview.appendChild(img); }
  }});
  body.appendChild(fileInput);
  // feeling & location
  const extraRow = el("div", { style: "display:flex;gap:8px;margin-top:8px;" });
  const feelingInput = el("input", { class: "auth-input", placeholder: "شعور (اختياري)", style: "margin-bottom:0;flex:1;", oninput: (e) => createPostFeeling = e.target.value });
  const locationInput = el("input", { class: "auth-input", placeholder: "موقع (اختياري)", style: "margin-bottom:0;flex:1;", oninput: (e) => createPostLocation = e.target.value });
  extraRow.appendChild(feelingInput); extraRow.appendChild(locationInput);
  body.appendChild(extraRow);
  const addImg = el("div", { style: "display:flex;align-items:center;gap:8px;padding:8px;border:1px solid #DADDE1;border-radius:8px;cursor:pointer;margin-top:8px;", onclick: () => fileInput.click() }, [
    el("span", { style: "color:#45BD62;" }, [I("image",20)]), el("span", { style: "font-weight:600;" }, ["صورة/فيديو"]),
  ]);
  body.appendChild(addImg);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    const content = textarea.value.trim();
    if (!content && !createPostFile) { toast("المنشور فارغ"); return; }
    try {
      await API.uploadPost(content, createPostFile, { privacy: createPostPrivacy, feeling: createPostFeeling, location: createPostLocation });
      overlay.remove();
      toast("تم نشر المنشور");
      render();
    } catch(e) { toast(e.message); }
  }}, ["نشر"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  setTimeout(() => textarea.focus(), 50);
}

// ===== Post card =====
function renderPost(p) {
  const post = el("div", { class: "post", "data-id": p.id });
  // header
  const header = el("div", { class: "post-header" }, [
    el("img", { src: avatarUrl(p.user), onclick: () => navigate("profile", {id: p.user.id}) }),
    el("div", { style: "flex:1;" }, [
      el("div", { class: "post-user", onclick: () => navigate("profile", {id: p.user.id}), style: "cursor:pointer;" }, [p.user ? p.user.name : "مستخدم"]),
      el("div", { class: "post-time" }, [
        timeAgo(p.created_at),
        p.edited_at ? " · تم التعديل" : "",
        p.feeling ? ` · يشعر بـ ${p.feeling}` : "",
        p.location ? ` · في ${p.location}` : "",
        " · " + privacyLabel(p.privacy),
      ]),
    ]),
    el("div", { class: "post-more", onclick: (e) => { e.stopPropagation(); openPostMenu(post, p); } }, [I("more", 20)]),
  ]);
  post.appendChild(header);
  if (p.content) post.appendChild(el("div", { class: "post-content" }, [renderTextWithTags(p.content)]));
  if (p.image_url) {
    const img = el("img", { class: "post-image", src: p.image_url, onclick: () => openPhotoViewer(p.image_url) });
    post.appendChild(img);
  }
  // reactions summary
  if (p.likes_count > 0) {
    const summary = el("div", { class: "post-stats" }, [
      el("div", { class: "reactions-summary" }, renderReactionSummary(p)),
      el("div", {}, [p.comments_count ? (p.comments_count + " تعليق") : "", p.likes_count ? "" : ""]),
    ]);
    post.appendChild(summary);
  } else if (p.comments_count > 0) {
    post.appendChild(el("div", { class: "post-stats" }, [
      el("div", {}, [""]),
      el("div", {}, [p.comments_count + " تعليق"]),
    ]));
  }
  // actions
  const actions = el("div", { class: "post-actions" });
  const likeBtn = renderReactionButton(p, post);
  const commentBtn = el("div", { class: "post-action", onclick: () => {
    const input = post.querySelector(".comment-input");
    if (input) input.focus();
  }}, [I("comment", 20), " تعليق"]);
  const shareBtn = el("div", { class: "post-action", onclick: () => openShareModal(p) }, [I("share", 20), " مشاركة"]);
  const saveBtn = el("div", { class: "post-action", onclick: async () => {
    try {
      await API.post(`/api/posts/${p.id}/save`);
      toast("تم الحفظ");
    } catch(e) { toast(e.message); }
  }}, [I("bookmark", 20), " حفظ"]);
  actions.appendChild(likeBtn); actions.appendChild(commentBtn); actions.appendChild(shareBtn); actions.appendChild(saveBtn);
  post.appendChild(actions);
  // comments
  const commentsWrap = el("div", { class: "comments" });
  const commentsList = el("div", { class: "comments-list" });
  commentsWrap.appendChild(commentsList);
  loadComments(commentsList, p.id);
  const inputRow = el("div", { class: "comment-input-row" }, [
    el("img", { src: avatarUrl(state.user) }),
    el("input", { class: "comment-input", placeholder: "اكتب تعليقاً...", onkeydown: async (e) => {
      if (e.key === "Enter" && e.target.value.trim()) {
        try {
          const d = await API.post(`/api/posts/${p.id}/comments`, { content: e.target.value.trim() });
          e.target.value = "";
          appendComment(commentsList, d.comment, p);
        } catch(err) { toast(err.message); }
      }
    }}),
  ]);
  commentsWrap.appendChild(inputRow);
  post.appendChild(commentsWrap);
  return post;
}

function privacyLabel(pr) {
  if (pr === "friends") return "👥";
  if (pr === "only_me") return "🔒";
  return "🌍";
}
function renderReactionSummary(p) {
  const out = [];
  const entries = Object.entries(p.reactions || {}).sort((a,b)=>b[1]-a[1]);
  for (const [k, v] of entries.slice(0,3)) {
    const r = reactionInfo(k);
    out.push(el("span", {}, [r.emoji]));
  }
  if (p.likes_count > 0) out.push(el("span", { style: "margin-right:6px;color:#65676B;font-size:13px;" }, [p.likes_count]));
  return out;
}
function renderReactionButton(p, post) {
  const myR = p.my_reaction;
  const info = myR ? reactionInfo(myR) : { emoji: "👍", label: "إعجاب", color: "#65676B" };
  const btn = el("div", { class: "post-action reaction-btn" + (myR ? " reacted" : ""), style: myR ? `color:${info.color};` : "", onclick: async () => {
    // toggle like
    try {
      if (myR) {
        await API.del(`/api/posts/${p.id}/like`);
        p.my_reaction = null; p.liked_by_me = false; p.likes_count = Math.max(0, p.likes_count-1);
        if (p.reactions[p._prevReaction||"like"]) p.reactions[p._prevReaction||"like"]--;
      } else {
        await API.post(`/api/posts/${p.id}/like`, { reaction: "like" });
        p.my_reaction = "like"; p.liked_by_me = true; p.likes_count++;
        p.reactions["like"] = (p.reactions["like"]||0)+1;
      }
      const newPost = renderPost(p);
      post.replaceWith(newPost);
    } catch(e) { toast(e.message); }
  }});
  btn.appendChild(el("span", { class: "ico" }, [info.emoji]));
  btn.appendChild(document.createTextNode(" " + info.label));
  // reaction picker on hover
  let picker = null;
  btn.addEventListener("mouseenter", () => {
    if (picker) return;
    picker = el("div", { class: "reaction-picker" });
    for (const r of REACTIONS) {
      const sp = el("span", { onclick: async (e) => {
        e.stopPropagation();
        try {
          await API.post(`/api/posts/${p.id}/like`, { reaction: r.key });
          // update counts
          if (p.my_reaction && p.reactions[p.my_reaction]) p.reactions[p.my_reaction] = Math.max(0, p.reactions[p.my_reaction]-1);
          p.my_reaction = r.key; p.liked_by_me = true;
          if (!p.reactions[r.key]) p.reactions[r.key] = 0;
          p.reactions[r.key]++;
          if (!p._wasLiked) { p.likes_count++; p._wasLiked = true; }
          const newPost = renderPost(p);
          post.replaceWith(newPost);
        } catch(e) { toast(e.message); }
        if (picker) { picker.remove(); picker = null; }
      }}, [r.emoji]);
      picker.appendChild(sp);
    }
    btn.appendChild(picker);
  });
  btn.addEventListener("mouseleave", () => {
    setTimeout(() => { if (picker) { picker.remove(); picker = null; } }, 300);
  });
  return btn;
}

function renderTextWithTags(text) {
  // hashtags and mentions
  const parts = text.split(/(\s+)/);
  const frag = document.createDocumentFragment();
  for (const part of parts) {
    if (part.startsWith("#")) {
      const span = el("span", { class: "hashtag", onclick: () => navigate("search", {q: part}) }, [part]);
      frag.appendChild(span);
    } else if (part.startsWith("@")) {
      const span = el("span", { class: "mention" }, [part]);
      frag.appendChild(span);
    } else {
      frag.appendChild(document.createTextNode(part));
    }
  }
  return frag;
}

function openPostMenu(post, p) {
  const menu = el("div", { style: "position:absolute;background:#fff;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.2);padding:8px;z-index:1000;min-width:180px;" });
  const items = [];
  if (p.user.id === state.user.id) {
    items.push({ icon: "edit", label: "تعديل المنشور", fn: () => openEditPostModal(p) });
    items.push({ icon: p.pinned ? "close" : "bookmark", label: p.pinned ? "إلغاء تثبيت المنشور" : "تثبيت المنشور", fn: async () => { if (p.pinned) await API.del(`/api/posts/${p.id}/pin`); else await API.post(`/api/posts/${p.id}/pin`); toast("تم"); render(); } });
    items.push({ icon: "trash", label: "حذف المنشور", fn: async () => { if (confirm("حذف المنشور؟")) { await API.del(`/api/posts/${p.id}`); toast("تم الحذف"); render(); } } });
  }
  items.push({ icon: "bookmark", label: "حفظ المنشور", fn: async () => { await API.post(`/api/posts/${p.id}/save`); toast("تم الحفظ"); } });
  items.push({ icon: "close", label: "إخفاء المنشور", fn: () => { post.remove(); toast("تم الإخفاء"); } });
  items.push({ icon: "more", label: "الإبلاغ", fn: () => toast("تم الإبلاغ") });
  for (const it of items) {
    const row = el("div", { style: "padding:8px 12px;cursor:pointer;border-radius:6px;display:flex;align-items:center;gap:8px;", onclick: () => { menu.remove(); it.fn(); } }, [I(it.icon, 18), el("span", {}, [it.label])]);
    row.addEventListener("mouseenter", () => row.style.background = "#F2F2F2");
    row.addEventListener("mouseleave", () => row.style.background = "");
    menu.appendChild(row);
  }
  // position
  const rect = post.querySelector(".post-more").getBoundingClientRect();
  menu.style.top = (rect.bottom + 4) + "px";
  menu.style.left = (rect.left - 160) + "px";
  menu.style.position = "fixed";
  document.body.appendChild(menu);
  setTimeout(() => document.addEventListener("click", function c(e) { if (!menu.contains(e.target)) { menu.remove(); document.removeEventListener("click", c); } }), 50);
}

function openEditPostModal(p) {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["تعديل المنشور"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  const ta = el("textarea", { style: "width:100%;min-height:100px;border:1px solid #DADDE1;border-radius:6px;padding:8px;outline:none;resize:none;font-size:16px;font-family:inherit;" });
  ta.value = p.content;
  body.appendChild(ta);
  const priv = el("select", { class: "auth-input", style: "margin-top:8px;" }, [
    el("option", { value: "public", selected: p.privacy==="public" }, ["🌍 للجميع"]),
    el("option", { value: "friends", selected: p.privacy==="friends" }, ["👥 أصدقاء"]),
    el("option", { value: "only_me", selected: p.privacy==="only_me" }, ["🔒 أنا فقط"]),
  ]);
  body.appendChild(priv);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      await API.put(`/api/posts/${p.id}`, { content: ta.value, privacy: priv.value });
      overlay.remove();
      toast("تم التعديل");
      render();
    } catch(e) { toast(e.message); }
  }}, ["حفظ"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

function openShareModal(p) {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["مشاركة"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  body.appendChild(el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:12px;" }, [
    el("img", { src: avatarUrl(state.user), style: "width:40px;height:40px;border-radius:50%;object-fit:cover;" }),
    el("div", { style: "font-weight:600;" }, [state.user.name]),
  ]));
  const ta = el("textarea", { placeholder: "قل شيئاً عن هذا...", style: "width:100%;min-height:60px;border:1px solid #DADDE1;border-radius:6px;padding:8px;outline:none;resize:none;font-size:15px;font-family:inherit;" });
  body.appendChild(ta);
  // preview original
  const preview = el("div", { style: "border:1px solid #DADDE1;border-radius:8px;padding:8px;margin-top:8px;" });
  preview.appendChild(el("div", { style: "font-weight:600;font-size:13px;" }, [p.user.name]));
  preview.appendChild(el("div", { style: "font-size:14px;" }, [p.content]));
  if (p.image_url) preview.appendChild(el("img", { src: p.image_url, style: "width:100%;border-radius:6px;margin-top:4px;" }));
  body.appendChild(preview);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      const shareText = ta.value.trim() + "\n\n---\n" + (p.content || "");
      await API.post("/api/posts", { content: shareText, privacy: "public" });
      overlay.remove();
      toast("تمت المشاركة");
      render();
    } catch(e) { toast(e.message); }
  }}, ["مشاركة الآن"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

// ===== Comments =====
async function loadComments(container, postId) {
  try {
    const d = await API.get(`/api/posts/${postId}/comments`);
    container.innerHTML = "";
    for (const c of d.comments) appendComment(container, c, postId);
  } catch(e) {}
}
function appendComment(container, c, postId) {
  const row = el("div", { class: "comment", "data-id": c.id }, [
    el("img", { src: avatarUrl(c.user), onclick: () => navigate("profile", {id: c.user.id}) }),
    el("div", { style: "flex:1;" }, [
      el("div", { class: "comment-bubble" }, [
        el("div", { class: "comment-user" }, [c.user ? c.user.name : "مستخدم"]),
        el("div", { class: "comment-text" }, [c.content]),
      ]),
      el("div", { style: "display:flex;gap:12px;padding:2px 12px;font-size:12px;color:#65676B;" }, [
        el("span", { style: "cursor:pointer;font-weight:600;", onclick: async () => {
          try { await API.post(`/api/comments/${c.id}/like`); toast("أعجبك"); } catch(e) { toast(e.message); }
        }}, ["إعجاب"]),
        el("span", { style: "cursor:pointer;font-weight:600;", onclick: () => {
          const r = prompt("رد:");
          if (r) API.post(`/api/comments/${c.id}/reply`, { content: r }).then(d => {
            const replies = row.querySelector(".replies") || el("div", { class: "replies", style: "margin-right:32px;margin-top:4px;" });
            if (!row.querySelector(".replies")) row.appendChild(replies);
            appendComment(replies, d.comment, postId);
          }).catch(e=>toast(e.message));
        }}, ["رد"]),
        c.user && c.user.id === state.user.id ? el("span", { style: "cursor:pointer;font-weight:600;", onclick: async () => {
          const nc = prompt("تعديل:", c.content);
          if (nc) { await API.put(`/api/comments/${c.id}`, { content: nc }); toast("تم"); render(); }
        }}, ["تعديل"]) : null,
        (c.user && c.user.id === state.user.id) ? el("span", { style: "cursor:pointer;font-weight:600;", onclick: async () => {
          if (confirm("حذف التعليق؟")) { await API.del(`/api/comments/${c.id}`); row.remove(); toast("تم الحذف"); }
        }}, ["حذف"]) : null,
      ]),
      el("div", { class: "replies" }),
    ]),
  ]);
  container.appendChild(row);
}

// ===== Profile =====
async function renderProfile(main, id) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get(`/api/users/${id}`);
    const u = d.user;
    main.innerHTML = "";
    const cover = el("div", { class: "profile-cover" });
    if (u.cover_url) cover.appendChild(el("img", { src: u.cover_url }));
    else cover.style.background = "linear-gradient(135deg,#1877F2,#42B72A)";
    const avatarWrap = el("div", { class: "profile-avatar-wrap" }, [
      el("img", { class: "profile-avatar", src: avatarUrl(u) }),
    ]);
    cover.appendChild(avatarWrap);
    main.appendChild(cover);

    const info = el("div", { class: "profile-info" }, [
      el("div", { class: "profile-name" }, [u.name]),
      el("div", { class: "profile-bio" }, [u.bio || ""]),
      el("div", { class: "profile-stats" }, [
        el("div", {}, [el("b",{},[d.friends_count]), " صديق"]),
        el("div", {}, [el("b",{},[d.posts_count]), " منشور"]),
      ]),
    ]);
    const actions = el("div", { class: "profile-actions" });
    if (state.user.id === u.id) {
      actions.appendChild(el("button", { class: "btn btn-gray", onclick: openEditProfile }, ["✏️ تحرير الملف الشخصي"]));
      actions.appendChild(el("button", { class: "btn btn-gray", onclick: () => navigate("settings") }, ["⚙️ الإعدادات"]));
    } else {
      if (d.relation === "accepted") {
        actions.appendChild(el("button", { class: "btn btn-gray", onclick: async () => { await API.del(`/api/friends/${u.id}`); toast("تم إلغاء الصداقة"); render(); } }, ["✓ أصدقاء"]));
      } else if (d.relation === "pending") {
        actions.appendChild(el("button", { class: "btn btn-gray" }, ["⏳ طلب مرسل"]));
      } else if (d.relation === "pending_received") {
        actions.appendChild(el("button", { class: "btn btn-primary", onclick: async () => {
          const r = await API.get("/api/friend-requests");
          const req = r.requests.find(x => x.id === u.id);
          if (req) { await API.post("/api/friends/accept", { requestId: req.request_id }); toast("تم قبول الطلب"); render(); }
        }}, ["قبول"]));
      } else {
        actions.appendChild(el("button", { class: "btn btn-primary", onclick: async () => { await API.post("/api/friends/request", { userId: u.id }); toast("تم إرسال الطلب"); render(); } }, ["+ إضافة صديق"]));
      }
      actions.appendChild(el("button", { class: "btn btn-gray", onclick: () => navigate("messages", {id: u.id}) }, ["💬 مراسلة"]));
    }
    info.appendChild(actions);
    main.appendChild(info);

    // tabs
    const tabs = el("div", { class: "profile-tabs" });
    const tabNames = ["المنشورات","حول","الأصدقاء","الصور","الفيديوهات"];
    const tabContents = el("div", { class: "profile-content", style: "grid-template-columns:1fr;" });
    tabNames.forEach((t,i) => {
      const tab = el("div", { class: "profile-tab" + (i===0?" active":""), onclick: () => {
        $$(".profile-tab").forEach(x=>x.classList.remove("active"));
        tab.classList.add("active");
        $$(".tab-content").forEach(x=>x.classList.remove("active"));
        $(`#tab-${i}`).classList.add("active");
      }}, [t]);
      tabs.appendChild(tab);
    });
    main.appendChild(tabs);

    // tab contents
    // 0 posts
    const postsTab = el("div", { class: "tab-content active", id: "tab-0", style: "max-width:680px;margin:0 auto;padding:16px;" });
    const postsWrap = el("div", { id: "profile-posts" });
    postsTab.appendChild(postsWrap);
    tabContents.appendChild(postsTab);
    // 1 about
    const aboutTab = el("div", { class: "tab-content", id: "tab-1", style: "max-width:680px;margin:0 auto;padding:16px;" });
    aboutTab.appendChild(renderAboutCard(u));
    tabContents.appendChild(aboutTab);
    // 2 friends
    const friendsTab = el("div", { class: "tab-content", id: "tab-2", style: "max-width:900px;margin:0 auto;padding:16px;" });
    const friendsGrid = el("div", { id: "profile-friends", class: "friends-grid-big" });
    friendsTab.appendChild(friendsGrid);
    tabContents.appendChild(friendsTab);
    // 3 photos
    const photosTab = el("div", { class: "tab-content", id: "tab-3", style: "max-width:900px;margin:0 auto;padding:16px;" });
    const photosGrid = el("div", { id: "profile-photos", style: "display:grid;grid-template-columns:repeat(4,1fr);gap:4px;" });
    photosTab.appendChild(photosGrid);
    tabContents.appendChild(photosTab);
    // 4 videos
    const videosTab = el("div", { class: "tab-content", id: "tab-4", style: "max-width:900px;margin:0 auto;padding:16px;" });
    videosTab.appendChild(el("div", { class: "empty" }, ["لا توجد فيديوهات yet."]));
    tabContents.appendChild(videosTab);
    main.appendChild(tabContents);

    // load data
    const pd = await API.get(`/api/users/${id}/posts`);
    postsWrap.innerHTML = "";
    if (!pd.posts.length) postsWrap.appendChild(el("div", { class: "empty" }, ["لا توجد منشورات."]));
    for (const p of pd.posts) postsWrap.appendChild(renderPost(p));

    const fd = await API.get(`/api/users/${id}/friends`);
    friendsGrid.innerHTML = "";
    for (const f of fd.friends) {
      const tile = el("div", { class: "friend-card", onclick: () => navigate("profile", {id: f.id}) }, [
        el("img", { src: avatarUrl(f) }),
        el("div", { class: "name" }, [f.name]),
      ]);
      friendsGrid.appendChild(tile);
    }
    if (!fd.friends.length) friendsGrid.appendChild(el("div", { class: "empty" }, ["لا توجد أصدقاء."]));

    const ph = await API.get(`/api/users/${id}/photos`);
    photosGrid.innerHTML = "";
    for (const pho of ph.photos) {
      const img = el("img", { src: pho.url, style: "width:100%;aspect-ratio:1;object-fit:cover;cursor:pointer;border-radius:4px;", onclick: () => openPhotoViewer(pho.url) });
      photosGrid.appendChild(img);
    }
    if (!ph.photos.length) photosGrid.appendChild(el("div", { class: "empty" }, ["لا توجد صور."]));
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

function renderAboutCard(u) {
  const card = el("div", { class: "profile-left-card", style: "max-width:680px;" });
  card.appendChild(el("div", { class: "card-title" }, ["مقدمة"]));
  const fields = [
    ["bio","📝", u.bio],
    ["workplace","💼", u.workplace ? "يعمل في " + u.workplace : ""],
    ["education","🎓", u.education ? "درس في " + u.education : ""],
    ["location","📍", u.location ? "يعيش في " + u.location : ""],
    ["phone","📞", u.phone],
    ["website","🔗", u.website],
    ["gender","👤", u.gender === "male" ? "ذكر" : u.gender === "female" ? "أنثى" : ""],
    ["birthday","🎂", u.birthday],
    ["relationship","❤️", u.relationship],
  ];
  for (const [k,ico,val] of fields) {
    if (val) card.appendChild(el("div", { class: "info-row" }, [el("span",{class:"ico"},[ico]), val]));
  }
  card.appendChild(el("div", { class: "info-row" }, [el("span",{class:"ico"},["📅"]), "انضم في " + new Date(u.created_at).toLocaleDateString("ar")]));
  return card;
}

function openEditProfile() {
  const u = state.user;
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["تحرير الملف الشخصي"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  const fields = [
    ["name","الاسم","text", u.name],
    ["bio","نبذة","text", u.bio],
    ["location","الموقع","text", u.location],
    ["workplace","مكان العمل","text", u.workplace],
    ["education","التعليم","text", u.education],
    ["phone","الهاتف","text", u.phone],
    ["website","الموقع الإلكتروني","text", u.website],
    ["birthday","تاريخ الميلاد","date", u.birthday],
    ["relationship","الحالة الاجتماعية","text", u.relationship],
    ["avatar_url","رابط الصورة الشخصية","text", u.avatar_url],
    ["cover_url","رابط صورة الغلاف","text", u.cover_url],
  ];
  const inputs = {};
  for (const [k,label,type,val] of fields) {
    body.appendChild(el("label", { style: "font-weight:600;font-size:14px;display:block;margin-bottom:4px;" }, [label]));
    const inp = el("input", { class: "auth-input", type, value: val || "" });
    inputs[k] = inp;
    body.appendChild(inp);
  }
  // gender
  body.appendChild(el("label", { style: "font-weight:600;font-size:14px;display:block;margin-bottom:4px;" }, ["الجنس"]));
  const gsel = el("select", { class: "auth-input" }, [
    el("option", { value: "" }, ["—"]),
    el("option", { value: "male", selected: u.gender==="male" }, ["ذكر"]),
    el("option", { value: "female", selected: u.gender==="female" }, ["أنثى"]),
  ]);
  inputs.gender = gsel;
  body.appendChild(gsel);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style:"margin-top:0;", onclick: async () => {
    const payload = {};
    for (const k in inputs) payload[k] = inputs[k].value;
    try {
      const d = await API.put("/api/settings", payload);
      state.user = d.user;
      overlay.remove();
      toast("تم الحفظ");
      navigate("profile", {id: u.id});
    } catch(e) { toast(e.message); }
  }}, ["حفظ"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

// ===== Friends =====
async function renderFriends(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const [fr, req] = await Promise.all([API.get("/api/friends"), API.get("/api/friend-requests")]);
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    page.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الأصدقاء"]));
    if (req.requests.length) {
      page.appendChild(el("h3", { style: "margin:12px 0;" }, ["طلبات الصداقة (" + req.requests.length + ")"]));
      const rg = el("div", { class: "friends-grid-big" });
      for (const r of req.requests) {
        const card = el("div", { class: "friend-card" }, [
          el("img", { src: avatarUrl(r) }),
          el("div", { class: "name" }, [r.name]),
          el("div", { class: "mutual" }, ["يريد إضافتك كصديق"]),
          el("div", { style: "display:flex;gap:6px;margin-top:8px;justify-content:center;" }, [
            el("button", { class: "btn btn-primary", onclick: async () => { await API.post("/api/friends/accept", { requestId: r.request_id }); toast("تم قبول الطلب"); render(); } }, ["تأكيد"]),
            el("button", { class: "btn btn-gray", onclick: async () => { await API.post("/api/friends/decline", { requestId: r.request_id }); toast("تم الرفض"); render(); } }, ["حذف"]),
          ]),
        ]);
        rg.appendChild(card);
      }
      page.appendChild(rg);
    }
    page.appendChild(el("h3", { style: "margin:16px 0 8px;" }, ["كل الأصدقاء (" + fr.friends.length + ")"]));
    const grid = el("div", { class: "friends-grid-big" });
    for (const f of fr.friends) {
      const card = el("div", { class: "friend-card" }, [
        el("img", { src: avatarUrl(f), onclick: () => navigate("profile", {id: f.id}) }),
        el("div", { class: "name", onclick: () => navigate("profile", {id: f.id}) }, [f.name]),
        el("div", { class: "mutual" }, ["صديق"]),
        el("button", { class: "btn btn-gray", style: "margin-top:8px;width:100%;", onclick: async (e) => { e.stopPropagation(); await API.del(`/api/friends/${f.id}`); toast("تم إلغاء الصداقة"); render(); } }, ["إلغاء صداقة"]),
      ]);
      grid.appendChild(card);
    }
    page.appendChild(grid);
    // suggestions
    const sd = await API.get("/api/users/search?q=");
    const suggestions = sd.users.filter(u => !fr.friends.find(f=>f.id===u.id)).slice(0,8);
    if (suggestions.length) {
      page.appendChild(el("h3", { style: "margin:16px 0 8px;" }, ["قد تعرف"]));
      const sg = el("div", { class: "friends-grid-big" });
      for (const u of suggestions) {
        const card = el("div", { class: "friend-card" }, [
          el("img", { src: avatarUrl(u), onclick: () => navigate("profile", {id: u.id}) }),
          el("div", { class: "name" }, [u.name]),
          el("div", { class: "mutual" }, ["اقتراح"]),
          el("button", { class: "btn btn-primary", style: "margin-top:8px;width:100%;", onclick: async () => { await API.post("/api/friends/request", { userId: u.id }); toast("تم إرسال الطلب"); render(); } }, ["+ إضافة صديق"]),
        ]);
        sg.appendChild(card);
      }
      page.appendChild(sg);
    }
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Messages =====
async function renderMessages(main, partnerId) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/conversations");
    main.innerHTML = "";
    const page = el("div", { class: "messages-page" });
    const list = el("div", { class: "conv-list" });
    list.appendChild(el("div", { style: "padding:12px;font-size:20px;font-weight:700;border-bottom:1px solid #DADDE1;display:flex;justify-content:space-between;align-items:center;" }, [
      el("span", {}, ["الدردشة"]),
      el("span", { style: "font-size:14px;color:#1877F2;cursor:pointer;", onclick: () => {} }, ["+"]),
    ]));
    if (!d.conversations.length) {
      list.appendChild(el("div", { class: "empty", style: "padding:20px;" }, ["لا توجد محادثات. ابدأ بمراسلة صديق."]));
    }
    for (const c of d.conversations) {
      const item = el("div", { class: "conv-item" + (partnerId && parseInt(partnerId)===c.id ? " active" : ""), onclick: () => navigate("messages", {id: c.id}) }, [
        el("div", { style: "position:relative;" }, [
          el("img", { src: avatarUrl(c) }),
          el("span", { class: "online-dot" }),
        ]),
        el("div", { style: "flex:1;min-width:0;" }, [
          el("div", { class: "conv-name" }, [c.name]),
          el("div", { class: "conv-preview" }, [c.last_message ? c.last_message.content : ""]),
        ]),
        c.unread ? el("div", { style: "background:#1877F2;color:#fff;border-radius:50%;min-width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:12px;" }, [c.unread]) : null,
      ]);
      list.appendChild(item);
    }
    page.appendChild(list);

    const chat = el("div", { class: "chat-area" });
    if (partnerId) {
      const pd = await API.get(`/api/users/${partnerId}`);
      const partner = pd.user;
      const header = el("div", { class: "chat-header" }, [
        el("img", { src: avatarUrl(partner) }),
        el("div", { style: "flex:1;" }, [
          el("div", { style: "font-weight:600;" }, [partner.name]),
          el("div", { style: "color:#42B72A;font-size:13px;" }, ["نشط الآن"]),
        ]),
        el("div", { style: "display:flex;gap:8px;" }, [
          el("div", { class: "icon-btn", style: "width:32px;height:32px;font-size:16px;" }, ["📞"]),
          el("div", { class: "icon-btn", style: "width:32px;height:32px;font-size:16px;" }, ["📹"]),
          el("div", { class: "icon-btn", style: "width:32px;height:32px;font-size:16px;" }, ["ℹ️"]),
        ]),
      ]);
      chat.appendChild(header);
      const msgs = el("div", { class: "chat-messages", id: "chat-messages" });
      chat.appendChild(msgs);
      // typing indicator
      const typingEl = el("div", { class: "typing", id: "typing-indicator", style: "display:none;" }, [el("span"),el("span"),el("span")]);
      chat.appendChild(typingEl);
      const inputRow = el("div", { class: "chat-input" }, [
        el("div", { class: "icon-btn", style: "width:32px;height:32px;font-size:16px;" }, ["😊"]),
        el("input", { id: "chat-input", placeholder: "Aa", oninput: () => {
          // show typing to self? no-op
        }, onkeydown: async (e) => {
          if (e.key === "Enter" && e.target.value.trim()) {
            const content = e.target.value.trim();
            e.target.value = "";
            try {
              const md = await API.post("/api/messages", { to: parseInt(partnerId), content });
              appendBubble(msgs, md.message, true);
              msgs.scrollTop = msgs.scrollHeight;
            } catch(err) { toast(err.message); }
          }
        }}),
        el("div", { class: "icon-btn", style: "width:32px;height:32px;font-size:16px;", onclick: () => $("#chat-input").focus() }, ["📎"]),
        el("button", { class: "btn btn-primary", onclick: async () => {
          const inp = $("#chat-input");
          if (!inp.value.trim()) return;
          const content = inp.value.trim(); inp.value = "";
          try {
            const md = await API.post("/api/messages", { to: parseInt(partnerId), content });
            appendBubble(msgs, md.message, true);
            msgs.scrollTop = msgs.scrollHeight;
          } catch(err) { toast(err.message); }
        }}, ["إرسال"]),
      ]);
      chat.appendChild(inputRow);
      const md = await API.get(`/api/messages/${partnerId}`);
      msgs.innerHTML = "";
      for (const m of md.messages) appendBubble(msgs, m, m.sender_id === state.user.id);
      msgs.scrollTop = msgs.scrollHeight;
      await API.post(`/api/messages/${partnerId}/read`).catch(()=>{});
    } else {
      chat.appendChild(el("div", { class: "empty" }, ["اختر محادثة لبدء الدردشة"]));
    }
    page.appendChild(chat);
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}
function appendBubble(container, m, isMe) {
  const b = el("div", { class: "bubble " + (isMe ? "me" : "them"), "data-id": m.id }, [
    m.content,
    el("div", { style: "font-size:10px;opacity:0.7;margin-top:2px;text-align:" + (isMe?"left":"right") }, [timeAgo(m.created_at) + (isMe && m.read ? " · قُرئ" : "")]),
  ]);
  container.appendChild(b);
}

// ===== Search =====
async function renderSearch(main, q) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/search?q=" + encodeURIComponent(q||""));
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    page.appendChild(el("h2", { style: "margin-bottom:16px;" }, [`نتائج البحث: "${q||""}"`]));
    // tabs
    const tabs = el("div", { style: "display:flex;gap:8px;border-bottom:1px solid #DADDE1;margin-bottom:16px;" });
    const sections = [
      { key: "users", label: "الأشخاص", data: d.users },
      { key: "posts", label: "المنشورات", data: d.posts },
      { key: "groups", label: "المجموعات", data: d.groups },
      { key: "pages", label: "الصفحات", data: d.pages },
      { key: "events", label: "الأحداث", data: d.events },
      { key: "listings", label: "Marketplace", data: d.listings },
    ];
    const content = el("div", {});
    sections.forEach((s, i) => {
      const tab = el("div", { class: "profile-tab" + (i===0?" active":""), onclick: () => {
        $$(".search-tab").forEach(x=>x.classList.remove("active"));
        tab.classList.add("active");
        $$(".search-section").forEach(x=>x.style.display="none");
        $(`#search-${s.key}`).style.display = "block";
      }}, [s.label + ` (${s.data.length})`]);
      tab.classList.add("search-tab");
      tabs.appendChild(tab);
    });
    page.appendChild(tabs);
    // users section
    const usersSec = el("div", { class: "search-section", id: "search-users" });
    const ug = el("div", { class: "friends-grid-big" });
    for (const u of d.users) {
      const card = el("div", { class: "friend-card" }, [
        el("img", { src: avatarUrl(u), onclick: () => navigate("profile", {id: u.id}) }),
        el("div", { class: "name", onclick: () => navigate("profile", {id: u.id}) }, [u.name]),
        el("button", { class: "btn btn-primary", style: "margin-top:8px;width:100%;", onclick: async () => { await API.post("/api/friends/request", { userId: u.id }); toast("تم إرسال الطلب"); } }, ["+ إضافة صديق"]),
      ]);
      ug.appendChild(card);
    }
    if (!d.users.length) ug.appendChild(el("div", { class: "empty" }, ["لا توجد نتائج."]));
    usersSec.appendChild(ug);
    content.appendChild(usersSec);
    // posts section
    const postsSec = el("div", { class: "search-section", id: "search-posts", style: "display:none;" });
    for (const p of d.posts) postsSec.appendChild(renderPost(p));
    if (!d.posts.length) postsSec.appendChild(el("div", { class: "empty" }, ["لا توجد نتائج."]));
    content.appendChild(postsSec);
    // groups
    const groupsSec = el("div", { class: "search-section", id: "search-groups", style: "display:none;" });
    const gg = el("div", { class: "card-grid" });
    for (const g of d.groups) {
      const card = el("div", { class: "item-card", onclick: () => navigate("group", {id: g.id}) }, [
        el("div", { style: "height:120px;background:linear-gradient(135deg,#1877F2,#42B72A);display:flex;align-items:center;justify-content:center;color:#fff;font-size:24px;font-weight:700;" }, [g.name.charAt(0)]),
        el("div", { class: "body" }, [el("div", { class: "title" }, [g.name]), el("div", { class: "meta" }, [g.members_count ? g.members_count + " عضو" : "مجموعة"])]),
      ]);
      gg.appendChild(card);
    }
    if (!d.groups.length) gg.appendChild(el("div", { class: "empty" }, ["لا توجد نتائج."]));
    groupsSec.appendChild(gg);
    content.appendChild(groupsSec);
    // pages
    const pagesSec = el("div", { class: "search-section", id: "search-pages", style: "display:none;" });
    const pg = el("div", { class: "card-grid" });
    for (const pg_ of d.pages) {
      const card = el("div", { class: "item-card", onclick: () => navigate("page", {id: pg_.id}) }, [
        el("img", { src: pg_.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(pg_.name)}&background=1877F2&color=fff&size=200`, style: "height:120px;" }),
        el("div", { class: "body" }, [el("div", { class: "title" }, [pg_.name]), el("div", { class: "meta" }, [pg_.category || "صفحة"])]),
      ]);
      pg.appendChild(card);
    }
    if (!d.pages.length) pg.appendChild(el("div", { class: "empty" }, ["لا توجد نتائج."]));
    pagesSec.appendChild(pg);
    content.appendChild(pagesSec);
    // events
    const eventsSec = el("div", { class: "search-section", id: "search-events", style: "display:none;" });
    const eg = el("div", { class: "card-grid" });
    for (const e of d.events) {
      const card = el("div", { class: "item-card", onclick: () => navigate("event", {id: e.id}) }, [
        el("div", { style: "height:120px;background:linear-gradient(135deg,#F3425F,#F7B928);display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px;font-weight:700;" }, [e.name.charAt(0)]),
        el("div", { class: "body" }, [el("div", { class: "title" }, [e.name]), el("div", { class: "meta" }, [e.location || "حدث"])]),
      ]);
      eg.appendChild(card);
    }
    if (!d.events.length) eg.appendChild(el("div", { class: "empty" }, ["لا توجد نتائج."]));
    eventsSec.appendChild(eg);
    content.appendChild(eventsSec);
    // listings
    const listSec = el("div", { class: "search-section", id: "search-listings", style: "display:none;" });
    const lg = el("div", { class: "card-grid" });
    for (const l of d.listings) {
      const card = el("div", { class: "item-card", onclick: () => navigate("listing", {id: l.id}) }, [
        el("div", { style: "height:120px;background:#E4E6EB;display:flex;align-items:center;justify-content:center;font-size:40px;" }, ["🛍"]),
        el("div", { class: "body" }, [el("div", { class: "title" }, [l.title]), el("div", { class: "meta" }, [l.price + " " + l.currency])]),
      ]);
      lg.appendChild(card);
    }
    if (!d.listings.length) lg.appendChild(el("div", { class: "empty" }, ["لا توجد نتائج."]));
    listSec.appendChild(lg);
    content.appendChild(listSec);

    page.appendChild(content);
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Settings =====
async function renderSettings(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/settings");
    const s = d.settings;
    main.innerHTML = "";
    const page = el("div", { class: "settings-page" });
    const nav = el("div", { class: "settings-nav" });
    const content = el("div", { class: "settings-content", id: "settings-content" });
    const sections = [
      { key: "account", label: "", icon: "gear", text: "الحساب", render: () => renderSettingsAccount(content, s) },
      { key: "profile", label: "", icon: "user", text: "الملف الشخصي", render: () => renderSettingsProfile(content, s) },
      { key: "privacy", label: "", icon: "close", text: "الخصوصية", render: () => renderSettingsPrivacy(content) },
      { key: "security", label: "", icon: "check", text: "الأمان", render: () => renderSettingsSecurity(content) },
      { key: "theme", label: "", icon: "smile", text: "المظهر", render: () => renderSettingsTheme(content) },
      { key: "language", label: "", icon: "globe", text: "اللغة والمنطقة", render: () => renderSettingsLanguage(content) },
      { key: "notifications", label: "", icon: "bell", text: "الإشعارات", render: () => renderSettingsNotifications(content) },
      { key: "blocked", label: "", icon: "close", text: "المحظورون", render: () => renderSettingsBlocked(content) },
    ];
    for (const sec of sections) {
      const item = el("div", { class: "settings-nav-item", onclick: () => {
        $$(".settings-nav-item").forEach(x=>x.classList.remove("active"));
        item.classList.add("active");
        content.innerHTML = "";
        sec.render();
      }}, [I(sec.icon, 18), " " + sec.text]);
      nav.appendChild(item);
    }
    nav.firstChild.classList.add("active");
    page.appendChild(nav);
    page.appendChild(content);
    main.appendChild(page);
    sections[0].render();
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}
function renderSettingsAccount(content, s) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الحساب"]));
  const form = el("div", {});
  const fields = [
    ["name","الاسم", state.user.name],
    ["email","البريد الإلكتروني", state.user.email],
  ];
  const inputs = {};
  for (const [k,label,val] of fields) {
    form.appendChild(el("label", { style: "font-weight:600;display:block;margin:8px 0 4px;" }, [label]));
    const inp = el("input", { class: "auth-input", value: val || "" });
    inputs[k] = inp;
    form.appendChild(inp);
  }
  form.appendChild(el("button", { class: "auth-btn", style: "margin-top:12px;", onclick: async () => {
    try {
      const payload = {};
      for (const k in inputs) payload[k] = inputs[k].value;
      const d = await API.put("/api/settings", payload);
      state.user = d.user;
      toast("تم الحفظ");
    } catch(e) { toast(e.message); }
  }}, ["حفظ"]));
  content.appendChild(form);
  content.appendChild(el("div", { style: "margin-top:24px;padding-top:16px;border-top:1px solid #DADDE1;" }, [
    el("h3", { style: "margin-bottom:8px;" }, ["منطقة الخطر"]),
    el("button", { class: "btn", style: "background:#FEE2E2;color:#E41E3F;", onclick: () => { if (confirm("حذف الحساب؟")) toast("تم إرسال طلب الحذف"); } }, ["🗑 حذف الحساب"]),
  ]));
}
function renderSettingsProfile(content, s) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الملف الشخصي"]));
  content.appendChild(el("p", { style: "color:#65676B;margin-bottom:12px;" }, ["قم بتحرير ملفك الشخصي من صفحة ملفك الشخصي."]));
  content.appendChild(el("button", { class: "btn btn-primary", onclick: () => navigate("profile", {id: state.user.id}) }, ["فتح الملف الشخصي"]));
}
function renderSettingsPrivacy(content) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الخصوصية"]));
  const items = [
    "من يمكنه رؤية منشوراتك؟",
    "من يمكنه إرسال طلبات صداقة؟",
    "من يمكنه رؤية قائمة أصدقائك؟",
    "من يمكنه البحث عنك؟",
  ];
  for (const it of items) {
    const row = el("div", { style: "display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid #DADDE1;" }, [
      el("span", {}, [it]),
      el("select", { class: "auth-input", style: "width:auto;margin-bottom:0;" }, [
        el("option", {}, ["الجميع"]),
        el("option", {}, ["الأصدقاء"]),
        el("option", {}, ["أنا فقط"]),
      ]),
    ]);
    content.appendChild(row);
  }
}
function renderSettingsSecurity(content) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الأمان"]));
  content.appendChild(el("div", { style: "padding:12px 0;border-bottom:1px solid #DADDE1;" }, [
    el("div", { style: "font-weight:600;" }, ["كلمة المرور"]),
    el("div", { style: "color:#65676B;font-size:14px;margin:4px 0;" }, ["آخر تغيير: غير معروف"]),
    el("button", { class: "btn btn-gray" }, ["تغيير كلمة المرور"]),
  ]));
  content.appendChild(el("div", { style: "padding:12px 0;border-bottom:1px solid #DADDE1;" }, [
    el("div", { style: "font-weight:600;" }, ["المصادقة (2FA)"]),
    el("div", { style: "color:#65676B;font-size:14px;margin:4px 0;" }, ["أضف طبقة أمان إضافية"]),
    el("button", { class: "btn btn-gray" }, ["تفعيل"]),
  ]));
  content.appendChild(el("div", { style: "padding:12px 0;" }, [
    el("div", { style: "font-weight:600;" }, ["الجلسات النشطة"]),
    el("div", { style: "color:#65676B;font-size:14px;margin:4px 0;" }, ["هذا الجهاز"]),
    el("button", { class: "btn btn-gray" }, ["تسجيل الخروج من جميع الأجهزة"]),
  ]));
}
function renderSettingsTheme(content) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["المظهر"]));
  const row = el("div", { style: "display:flex;gap:12px;" });
  for (const [k, label, emoji] of [["light","فاتح","☀️"],["dark","داكن","🌙"]]) {
    const card = el("div", { style: `flex:1;padding:20px;border:2px solid ${state.theme===k?'#1877F2':'#DADDE1'};border-radius:8px;cursor:pointer;text-align:center;`, onclick: async () => {
      applyTheme(k);
      await API.put("/api/settings", { theme: k });
      toast("تم تغيير المظهر");
      renderSettings($("#main"));
    }}, [el("div", { style: "font-size:32px;" }, [emoji]), el("div", { style: "font-weight:600;margin-top:8px;" }, [label])]);
    row.appendChild(card);
  }
  content.appendChild(row);
}
function renderSettingsLanguage(content) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["اللغة والمنطقة"]));
  content.appendChild(el("label", { style: "font-weight:600;display:block;margin:8px 0 4px;" }, ["اللغة"]));
  const sel = el("select", { class: "auth-input" }, [
    el("option", { value: "ar", selected: true }, ["العربية"]),
    el("option", { value: "en" }, ["English"]),
    el("option", { value: "fr" }, ["Français"]),
  ]);
  content.appendChild(sel);
  content.appendChild(el("button", { class: "auth-btn", style: "margin-top:12px;", onclick: async () => {
    await API.put("/api/settings", { language: sel.value });
    toast("تم الحفظ");
  }}, ["حفظ"]));
}
function renderSettingsNotifications(content) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الإشعارات"]));
  const items = ["التعليقات","الإعجابات","طلبات الصداقة","الرسائل","المنشورات","أعياد الميلاد"];
  for (const it of items) {
    content.appendChild(el("div", { style: "display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #DADDE1;" }, [
      el("span", {}, [it]),
      el("input", { type: "checkbox", checked: true }),
    ]));
  }
}
async function renderSettingsBlocked(content) {
  content.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["المحظورون"]));
  content.appendChild(el("div", { class: "empty" }, ["لا توجد حسابات محظورة."]));
}

// ===== Groups =====
async function renderGroups(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/groups");
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    const header = el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;" }, [
      el("h2", {}, ["المجموعات"]),
      el("button", { class: "btn btn-primary", onclick: openCreateGroup }, ["+ إنشاء مجموعة"]),
    ]);
    page.appendChild(header);
    const grid = el("div", { class: "card-grid" });
    for (const g of d.groups) {
      const card = el("div", { class: "item-card", onclick: () => navigate("group", {id: g.id}) }, [
        el("div", { style: "height:140px;background:linear-gradient(135deg,#1877F2,#42B72A);display:flex;align-items:center;justify-content:center;color:#fff;font-size:32px;font-weight:700;" }, [g.name.charAt(0)]),
        el("div", { class: "body" }, [
          el("div", { class: "title" }, [g.name]),
          el("div", { class: "meta" }, [g.members_count + " عضو · " + (g.privacy === "public" ? "عامة" : "خاصة")]),
          el("div", { style: "color:#65676B;font-size:13px;margin-top:4px;" }, [g.description || ""]),
        ]),
      ]);
      grid.appendChild(card);
    }
    if (!d.groups.length) grid.appendChild(el("div", { class: "empty" }, ["لا توجد مجموعات."]));
    page.appendChild(grid);
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}
function openCreateGroup() {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["إنشاء مجموعة"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  const name = el("input", { class: "auth-input", placeholder: "اسم المجموعة" });
  const desc = el("textarea", { class: "auth-input", placeholder: "الوصف", style: "min-height:60px;resize:none;" });
  const priv = el("select", { class: "auth-input" }, [
    el("option", { value: "public" }, ["عامة - أي شخص يمكنه الانضمام"]),
    el("option", { value: "private" }, ["خاصة - يتطلب موافقة"]),
  ]);
  body.appendChild(name); body.appendChild(desc); body.appendChild(priv);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      await API.post("/api/groups", { name: name.value, description: desc.value, privacy: priv.value });
      overlay.remove();
      toast("تم إنشاء المجموعة");
      navigate("groups");
    } catch(e) { toast(e.message); }
  }}, ["إنشاء"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}
async function renderGroupDetail(main, id) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const [gd, pd] = await Promise.all([API.get(`/api/groups/${id}`), API.get(`/api/groups/${id}/posts`)]);
    const g = gd.group;
    main.innerHTML = "";
    // cover
    const cover = el("div", { class: "profile-cover", style: "height:200px;" });
    cover.style.background = "linear-gradient(135deg,#1877F2,#42B72A)";
    main.appendChild(cover);
    const info = el("div", { class: "profile-info" }, [
      el("div", { class: "profile-name" }, [g.name]),
      el("div", { class: "profile-bio" }, [g.description || ""]),
      el("div", { class: "profile-stats" }, [el("div", {}, [el("b",{},[g.members_count]), " عضو"])]),
    ]);
    const actions = el("div", { class: "profile-actions" });
    if (g.is_member) {
      actions.appendChild(el("button", { class: "btn btn-gray", onclick: async () => { await API.del(`/api/groups/${id}/join`); toast("تم مغادرة المجموعة"); render(); } }, ["✓ عضو"]));
    } else {
      actions.appendChild(el("button", { class: "btn btn-primary", onclick: async () => { await API.post(`/api/groups/${id}/join`); toast("تم الانضمام"); render(); } }, ["+ انضمام"]));
    }
    info.appendChild(actions);
    main.appendChild(info);
    const content = el("div", { style: "max-width:680px;margin:0 auto;padding:16px;" });
    if (g.is_member) {
      const createBox = el("div", { class: "create-post", style: "margin-bottom:16px;" });
      const inp = el("div", { class: "create-post-input", onclick: async () => {
        const text = prompt("منشور جديد:");
        if (text) { await API.post(`/api/groups/${id}/posts`, { content: text }); toast("تم النشر"); render(); }
      }}, ["ماذا يدور في ذهنك؟"]);
      createBox.appendChild(inp);
      content.appendChild(createBox);
    }
    for (const p of pd.posts) content.appendChild(renderPost(p));
    if (!pd.posts.length) content.appendChild(el("div", { class: "empty" }, ["لا توجد منشورات yet."]));
    main.appendChild(content);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Pages =====
async function renderPages(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/pages");
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    const header = el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;" }, [
      el("h2", {}, ["الصفحات"]),
      el("button", { class: "btn btn-primary", onclick: openCreatePage }, ["+ إنشاء صفحة"]),
    ]);
    page.appendChild(header);
    const grid = el("div", { class: "card-grid" });
    for (const pg of d.pages) {
      const card = el("div", { class: "item-card", onclick: () => navigate("page", {id: pg.id}) }, [
        el("img", { src: pg.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(pg.name)}&background=1877F2&color=fff&size=200`, style: "height:140px;object-fit:cover;" }),
        el("div", { class: "body" }, [
          el("div", { class: "title" }, [pg.name]),
          el("div", { class: "meta" }, [pg.category || "صفحة", " · ", pg.followers_count, " متابع"]),
        ]),
      ]);
      grid.appendChild(card);
    }
    if (!d.pages.length) grid.appendChild(el("div", { class: "empty" }, ["لا توجد صفحات."]));
    page.appendChild(grid);
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}
function openCreatePage() {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["إنشاء صفحة"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  const name = el("input", { class: "auth-input", placeholder: "اسم الصفحة" });
  const cat = el("input", { class: "auth-input", placeholder: "الفئة (مثال: شركة، علامة تجارية)" });
  const about = el("textarea", { class: "auth-input", placeholder: "حول", style: "min-height:60px;resize:none;" });
  body.appendChild(name); body.appendChild(cat); body.appendChild(about);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      await API.post("/api/pages", { name: name.value, category: cat.value, about: about.value });
      overlay.remove();
      toast("تم إنشاء الصفحة");
      navigate("pages");
    } catch(e) { toast(e.message); }
  }}, ["إنشاء"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}
async function renderPageDetail(main, id) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get(`/api/pages/${id}`);
    const p = d.page;
    main.innerHTML = "";
    const cover = el("div", { class: "profile-cover", style: "height:200px;" });
    cover.style.background = "linear-gradient(135deg,#1877F2,#42B72A)";
    main.appendChild(cover);
    const info = el("div", { class: "profile-info" }, [
      el("div", { class: "profile-name" }, [p.name]),
      el("div", { class: "profile-bio" }, [p.about || ""]),
      el("div", { class: "profile-stats" }, [el("div", {}, [el("b",{},[p.followers_count]), " متابع"])]),
    ]);
    const actions = el("div", { class: "profile-actions" });
    if (p.is_following) {
      actions.appendChild(el("button", { class: "btn btn-gray", onclick: async () => { await API.del(`/api/pages/${id}/follow`); toast("تم إلغاء المتابعة"); render(); } }, ["✓ متابَع"]));
    } else {
      actions.appendChild(el("button", { class: "btn btn-primary", onclick: async () => { await API.post(`/api/pages/${id}/follow`); toast("تمت المتابعة"); render(); } }, ["+ متابعة"]));
    }
    info.appendChild(actions);
    main.appendChild(info);
    main.appendChild(el("div", { class: "empty" }, ["منشورات الصفحة — قريباً"]));
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Events =====
async function renderEvents(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/events");
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    const header = el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;" }, [
      el("h2", {}, ["الأحداث"]),
      el("button", { class: "btn btn-primary", onclick: openCreateEvent }, ["+ إنشاء حدث"]),
    ]);
    page.appendChild(header);
    const grid = el("div", { class: "card-grid" });
    for (const e of d.events) {
      const card = el("div", { class: "item-card", onclick: () => navigate("event", {id: e.id}) }, [
        el("div", { style: "height:140px;background:linear-gradient(135deg,#F3425F,#F7B928);display:flex;align-items:center;justify-content:center;color:#fff;font-size:24px;font-weight:700;" }, [e.name.charAt(0)]),
        el("div", { class: "body" }, [
          el("div", { class: "title" }, [e.name]),
          el("div", { class: "meta" }, [e.start_time || "حدث", " · ", e.going_count, " ذاهب"]),
          el("div", { style: "color:#65676B;font-size:13px;margin-top:4px;" }, [e.location || ""]),
        ]),
      ]);
      grid.appendChild(card);
    }
    if (!d.events.length) grid.appendChild(el("div", { class: "empty" }, ["لا توجد أحداث."]));
    page.appendChild(grid);
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}
function openCreateEvent() {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["إنشاء حدث"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  const name = el("input", { class: "auth-input", placeholder: "اسم الحدث" });
  const desc = el("textarea", { class: "auth-input", placeholder: "الوصف", style: "min-height:60px;resize:none;" });
  const loc = el("input", { class: "auth-input", placeholder: "الموقع" });
  const start = el("input", { class: "auth-input", type: "datetime-local", placeholder: "البداية" });
  body.appendChild(name); body.appendChild(desc); body.appendChild(loc); body.appendChild(start);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      await API.post("/api/events", { name: name.value, description: desc.value, location: loc.value, start_time: start.value });
      overlay.remove();
      toast("تم إنشاء الحدث");
      navigate("events");
    } catch(e) { toast(e.message); }
  }}, ["إنشاء"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}
async function renderEventDetail(main, id) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get(`/api/events/${id}`);
    const e = d.event;
    main.innerHTML = "";
    const cover = el("div", { class: "profile-cover", style: "height:200px;" });
    cover.style.background = "linear-gradient(135deg,#F3425F,#F7B928)";
    main.appendChild(cover);
    const info = el("div", { class: "profile-info" }, [
      el("div", { class: "profile-name" }, [e.name]),
      el("div", { class: "profile-bio" }, [e.description || ""]),
      el("div", { class: "profile-stats" }, [
        el("div", {}, [el("b",{},[e.going_count]), " ذاهب"]),
        el("div", {}, [e.start_time || ""]),
        el("div", {}, [e.location || ""]),
      ]),
    ]);
    const actions = el("div", { class: "profile-actions" });
    const statuses = [["going","سأذهب"],["interested","مهتم"],["not_going","لن أذهب"]];
    for (const [k,label] of statuses) {
      const btn = el("button", { class: e.my_status===k ? "btn btn-primary" : "btn btn-gray", onclick: async () => { await API.post(`/api/events/${id}/rsvp`, { status: k }); toast("تم"); render(); } }, [label]);
      actions.appendChild(btn);
    }
    info.appendChild(actions);
    main.appendChild(info);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Marketplace =====
async function renderMarketplace(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/marketplace");
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    const header = el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;gap:8px;flex-wrap:wrap;" }, [
      el("h2", {}, ["Marketplace"]),
      el("div", { style: "display:flex;gap:8px;" }, [
        el("input", { class: "auth-input", placeholder: "بحث...", style: "margin-bottom:0;width:200px;", onkeydown: async (e) => {
          if (e.key === "Enter") {
            const dd = await API.get("/api/marketplace?q=" + encodeURIComponent(e.target.value));
            // re-render grid
            grid.innerHTML = "";
            for (const l of dd.listings) grid.appendChild(renderListingCard(l));
          }
        }}),
        el("button", { class: "btn btn-primary", onclick: openCreateListing }, ["+ إنشاء إعلان"]),
      ]),
    ]);
    page.appendChild(header);
    const grid = el("div", { class: "card-grid", id: "market-grid" });
    for (const l of d.listings) grid.appendChild(renderListingCard(l));
    if (!d.listings.length) grid.appendChild(el("div", { class: "empty" }, ["لا توجد إعلانات."]));
    page.appendChild(grid);
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}
function renderListingCard(l) {
  return el("div", { class: "item-card", onclick: () => navigate("listing", {id: l.id}) }, [
    el("div", { style: "height:160px;background:#E4E6EB;display:flex;align-items:center;justify-content:center;font-size:48px;" }, ["🛍"]),
    el("div", { class: "body" }, [
      el("div", { class: "title" }, [l.title]),
      el("div", { style: "color:#1877F2;font-weight:700;font-size:16px;margin-top:4px;" }, [l.price + " " + l.currency]),
      el("div", { class: "meta" }, [l.location || ""]),
    ]),
  ]);
}
function openCreateListing() {
  const overlay = el("div", { class: "modal-overlay", onclick: (e) => { if(e.target===overlay) overlay.remove(); } });
  const modal = el("div", { class: "modal" });
  modal.appendChild(el("div", { class: "modal-header" }, [
    el("div", { class: "modal-title" }, ["إنشاء إعلان"]),
    el("div", { class: "modal-close", onclick: () => overlay.remove() }, ["✕"]),
  ]));
  const body = el("div", { class: "modal-body" });
  const title = el("input", { class: "auth-input", placeholder: "العنوان" });
  const desc = el("textarea", { class: "auth-input", placeholder: "الوصف", style: "min-height:60px;resize:none;" });
  const price = el("input", { class: "auth-input", type: "number", placeholder: "السعر" });
  const currency = el("select", { class: "auth-input" }, [
    el("option", { value: "USD" }, ["USD"]),
    el("option", { value: "IQD" }, ["IQD"]),
  ]);
  const cat = el("input", { class: "auth-input", placeholder: "الفئة" });
  const loc = el("input", { class: "auth-input", placeholder: "الموقع" });
  const cond = el("select", { class: "auth-input" }, [
    el("option", { value: "new" }, ["جديد"]),
    el("option", { value: "used" }, ["مستعمل"]),
  ]);
  body.appendChild(title); body.appendChild(desc); body.appendChild(price); body.appendChild(currency); body.appendChild(cat); body.appendChild(loc); body.appendChild(cond);
  modal.appendChild(body);
  const footer = el("div", { class: "modal-footer" });
  footer.appendChild(el("button", { class: "auth-btn", style: "margin-top:0;", onclick: async () => {
    try {
      await API.post("/api/marketplace", { title: title.value, description: desc.value, price: parseFloat(price.value)||0, currency: currency.value, category: cat.value, location: loc.value, condition: cond.value });
      overlay.remove();
      toast("تم إنشاء الإعلان");
      navigate("marketplace");
    } catch(e) { toast(e.message); }
  }}, ["نشر"]));
  modal.appendChild(footer);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}
async function renderListingDetail(main, id) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get(`/api/marketplace/${id}`);
    const l = d.listing;
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    page.appendChild(el("h2", {}, [l.title]));
    page.appendChild(el("div", { style: "color:#1877F2;font-weight:700;font-size:24px;margin:8px 0;" }, [l.price + " " + l.currency]));
    page.appendChild(el("div", { style: "color:#65676B;margin-bottom:16px;" }, [l.location || ""]));
    page.appendChild(el("div", { style: "background:#fff;border-radius:8px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,0.1);margin-bottom:16px;" }, [l.description || "لا يوجد وصف."]));
    page.appendChild(el("div", { style: "display:flex;align-items:center;gap:8px;" }, [
      el("img", { src: avatarUrl(l.seller), style: "width:40px;height:40px;border-radius:50%;" }),
      el("div", {}, [el("div", { style: "font-weight:600;" }, [l.seller ? l.seller.name : "بائع"]), el("div", { style: "color:#65676B;font-size:13px;" }, ["بائع"])]),
      el("button", { class: "btn btn-primary", style: "margin-right:auto;", onclick: () => { if (l.seller) navigate("messages", {id: l.seller.id}); } }, ["💬 مراسلة"]),
    ]));
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Memories =====
async function renderMemories(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/memories");
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    page.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["الذكريات"]));
    page.appendChild(el("div", { class: "memory-card" }, [
      el("div", { style: "font-size:20px;font-weight:700;" }, ["في مثل هذا اليوم"]),
      el("div", { style: "margin-top:4px;opacity:0.9;" }, ["إليك ما حدث في الأعوام السابقة"]),
    ]));
    if (!d.memories.length) {
      page.appendChild(el("div", { class: "empty" }, ["لا توجد ذكريات لليوم."]));
    }
    for (const p of d.memories) {
      page.appendChild(el("div", { style: "background:#fff;border-radius:8px;padding:4px;margin-bottom:8px;box-shadow:0 1px 2px rgba(0,0,0,0.1);" }, [
        el("div", { style: "color:#65676B;font-size:13px;padding:8px;" }, [new Date(p.created_at).getFullYear() + " · " + timeAgo(p.created_at)]),
        renderPost(p),
      ]));
    }
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Saved =====
async function renderSaved(main) {
  main.innerHTML = '<div class="spinner"></div>';
  try {
    const d = await API.get("/api/saved");
    main.innerHTML = "";
    const page = el("div", { class: "friends-page" });
    page.appendChild(el("h2", { style: "margin-bottom:16px;" }, ["المحفوظات"]));
    if (!d.posts.length) page.appendChild(el("div", { class: "empty" }, ["لا توجد منشورات محفوظة."]));
    for (const p of d.posts) page.appendChild(renderPost(p));
    main.appendChild(page);
  } catch(e) { main.innerHTML = `<div class="empty">${e.message}</div>`; }
}

// ===== Notifications =====
async function toggleNotif() {
  const existing = $("#notif-dropdown");
  if (existing) { existing.remove(); state.notifOpen = false; return; }
  state.notifOpen = true;
  const dd = el("div", { class: "dropdown", id: "notif-dropdown" });
  dd.appendChild(el("div", { style: "padding:12px;font-size:20px;font-weight:700;border-bottom:1px solid #DADDE1;display:flex;justify-content:space-between;" }, [
    el("span", {}, ["الإشعارات"]),
    el("span", { style: "font-size:14px;color:#1877F2;cursor:pointer;", onclick: async () => { await API.post("/api/notifications/read"); updateNotifBadge(); } }, ["تحديد كمقروء"]),
  ]));
  document.body.appendChild(dd);
  const btn = $("#notif-btn");
  const rect = btn.getBoundingClientRect();
  dd.style.top = "56px";
  dd.style.left = Math.max(8, rect.left - 320) + "px";
  await loadNotifDropdown(dd);
  setTimeout(() => {
    document.addEventListener("click", function closer(ev) {
      if (!dd.contains(ev.target) && !btn.contains(ev.target)) {
        dd.remove(); state.notifOpen = false; document.removeEventListener("click", closer);
      }
    });
  }, 100);
}
async function loadNotifDropdown(dd) {
  try {
    const d = await API.get("/api/notifications");
    // keep header
    const header = dd.firstChild;
    dd.innerHTML = "";
    dd.appendChild(header);
    if (!d.notifications.length) dd.appendChild(el("div", { class: "empty", style: "padding:20px;" }, ["لا توجد إشعارات."]));
    for (const n of d.notifications) {
      const item = el("div", { class: "notif-item" + (n.read ? "" : " unread"), onclick: async () => {
        await API.post("/api/notifications/read");
        if (n.type === "friend_request") navigate("friends");
        else if (n.type === "like" || n.type === "comment") navigate("feed");
      }}, [
        el("img", { src: n.actor_avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(n.actor_name||"U")}&background=1877F2&color=fff&size=96` }),
        el("div", { style: "flex:1;" }, [
          el("div", { class: "notif-text" }, [notifText(n)]),
          el("div", { class: "notif-time" }, [timeAgo(n.created_at)]),
        ]),
        el("div", { style: "color:#65676B;cursor:pointer;padding:4px;", onclick: (e) => { e.stopPropagation(); API.del(`/api/notifications/${n.id}`).then(()=>{ item.remove(); }); } }, ["✕"]),
      ]);
      dd.appendChild(item);
    }
    updateNotifBadge(d.unread);
  } catch(e) {}
}
function notifText(n) {
  const name = n.actor_name || "مستخدم";
  if (n.type === "like") return name + " أعجب بمنشورك.";
  if (n.type === "comment") return name + " علق على منشورك.";
  if (n.type === "friend_request") return name + " أرسل لك طلب صداقة.";
  if (n.type === "friend_accept") return name + " قبل طلب صداقتك.";
  return "إشعار جديد";
}
function updateNotifBadge(count) {
  const badge = $("#notif-badge");
  if (!badge) return;
  if (count == null) {
    API.get("/api/notifications").then(d => {
      if (d.unread > 0) { badge.style.display = "flex"; badge.textContent = d.unread; }
      else badge.style.display = "none";
    }).catch(()=>{});
    return;
  }
  if (count > 0) { badge.style.display = "flex"; badge.textContent = count; }
  else badge.style.display = "none";
}

// ===== Photo viewer =====
function openPhotoViewer(url) {
  const v = el("div", { class: "photo-viewer", onclick: () => v.remove() }, [
    el("img", { src: url }),
  ]);
  document.body.appendChild(v);
}

// ===== Init =====
async function init() {
  await loadMe();
  if (state.user) {
    const h = location.hash.slice(1) || "feed";
    const [view, qs] = h.split("?");
    state.view = view || "feed";
    state.params = qs ? Object.fromEntries(new URLSearchParams(qs)) : {};
    render();
    setInterval(updateNotifBadge, 15000);
    setInterval(() => { if (state.view === "messages" && state.params.id) { /* poll messages */ } }, 5000);
    updateNotifBadge();
  } else {
    renderAuth("login");
  }
}
init();