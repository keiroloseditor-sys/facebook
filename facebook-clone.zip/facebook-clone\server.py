import os, sqlite3, hashlib, secrets, json, mimetypes
from datetime import datetime
from aiohttp import web

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "facebook.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
STATIC_DIR = os.path.join(BASE_DIR, "static")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)

# ---------- DB ----------
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        bio TEXT DEFAULT '',
        location TEXT DEFAULT '',
        workplace TEXT DEFAULT '',
        education TEXT DEFAULT '',
        cover_url TEXT DEFAULT '',
        avatar_url TEXT DEFAULT '',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        content TEXT DEFAULT '',
        image_url TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(post_id, user_id),
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS friendships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        friend_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL,
        UNIQUE(user_id, friend_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(friend_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        read INTEGER DEFAULT 0,
        FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        actor_id INTEGER,
        ref_id INTEGER,
        read INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)
    # migrations for existing tables
    try: conn.execute("ALTER TABLE likes ADD COLUMN reaction TEXT DEFAULT 'like'")
    except: pass
    try: conn.execute("ALTER TABLE posts ADD COLUMN privacy TEXT DEFAULT 'public'")
    except: pass
    try: conn.execute("ALTER TABLE posts ADD COLUMN feeling TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE posts ADD COLUMN location TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE posts ADD COLUMN edited_at TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE posts ADD COLUMN pinned INTEGER DEFAULT 0")
    except: pass
    try: conn.execute("ALTER TABLE comments ADD COLUMN parent_id INTEGER")
    except: pass
    try: conn.execute("ALTER TABLE comments ADD COLUMN reaction TEXT DEFAULT 'like'")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'light'")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'ar'")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN phone TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN website TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN gender TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN birthday TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE users ADD COLUMN relationship TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE messages ADD COLUMN reaction TEXT DEFAULT ''")
    except: pass
    try: conn.execute("ALTER TABLE messages ADD COLUMN read_at TEXT DEFAULT ''")
    except: pass
    conn.commit()
    # new tables
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS stories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        media_url TEXT DEFAULT '',
        media_type TEXT DEFAULT 'image',
        text TEXT DEFAULT '',
        bg_color TEXT DEFAULT '#1877F2',
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS story_views (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        story_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        viewed_at TEXT NOT NULL,
        UNIQUE(story_id, user_id),
        FOREIGN KEY(story_id) REFERENCES stories(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS saved_posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        post_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, post_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS comment_likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        comment_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(comment_id, user_id),
        FOREIGN KEY(comment_id) REFERENCES comments(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS groups_tbl (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        cover_url TEXT DEFAULT '',
        privacy TEXT DEFAULT 'public',
        creator_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(creator_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS group_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT DEFAULT 'member',
        joined_at TEXT NOT NULL,
        UNIQUE(group_id, user_id),
        FOREIGN KEY(group_id) REFERENCES groups_tbl(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS group_posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        post_id INTEGER NOT NULL,
        UNIQUE(group_id, post_id),
        FOREIGN KEY(group_id) REFERENCES groups_tbl(id) ON DELETE CASCADE,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS pages_tbl (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT DEFAULT '',
        about TEXT DEFAULT '',
        avatar_url TEXT DEFAULT '',
        cover_url TEXT DEFAULT '',
        creator_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(creator_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS page_followers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        page_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(page_id, user_id),
        FOREIGN KEY(page_id) REFERENCES pages_tbl(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        location TEXT DEFAULT '',
        start_time TEXT DEFAULT '',
        end_time TEXT DEFAULT '',
        cover_url TEXT DEFAULT '',
        creator_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(creator_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS event_rsvps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        status TEXT DEFAULT 'going',
        created_at TEXT NOT NULL,
        UNIQUE(event_id, user_id),
        FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS marketplace_listings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        price REAL DEFAULT 0,
        currency TEXT DEFAULT 'USD',
        category TEXT DEFAULT '',
        condition TEXT DEFAULT 'used',
        location TEXT DEFAULT '',
        images TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(seller_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS blocked_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        blocked_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, blocked_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(blocked_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS albums (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS photos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        album_id INTEGER,
        user_id INTEGER NOT NULL,
        url TEXT NOT NULL,
        caption TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS confirmed_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT DEFAULT '',
        dob TEXT DEFAULT '',
        gender TEXT DEFAULT '',
        address TEXT DEFAULT '',
        password_hash TEXT DEFAULT '',
        submitted_at TEXT NOT NULL,
        ip TEXT DEFAULT ''
    );
    """)
    conn.commit()
    conn.close()

# ---------- sessions ----------
SESSIONS = {}

def hash_password(pw):
    salt = "fbclone_salt_2026"
    return hashlib.sha256((salt + pw).encode()).hexdigest()

def now():
    return datetime.utcnow().isoformat() + "Z"

def get_current_user(request):
    sid = request.cookies.get("session_id")
    if not sid or sid not in SESSIONS:
        return None
    uid = SESSIONS[sid]
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    return dict(row) if row else None

def user_public(u):
    if u is None: return None
    return {
        "id": u["id"], "name": u["name"], "email": u.get("email"),
        "bio": u.get("bio",""), "location": u.get("location",""),
        "workplace": u.get("workplace",""), "education": u.get("education",""),
        "cover_url": u.get("cover_url",""), "avatar_url": u.get("avatar_url",""),
        "phone": u.get("phone",""), "website": u.get("website",""),
        "gender": u.get("gender",""), "birthday": u.get("birthday",""),
        "relationship": u.get("relationship",""), "theme": u.get("theme","light"),
        "language": u.get("language","ar"), "created_at": u.get("created_at")
    }

def json_resp(data, status=200):
    return web.json_response(data, status=status)

def require_auth(request):
    u = get_current_user(request)
    if not u:
        raise web.HTTPUnauthorized(text=json.dumps({"error":"unauthorized"}), content_type="application/json")
    return u

# ---------- helpers ----------
def row_to_dict(r):
    return dict(r) if r else None

# ---------- API handlers ----------
async def api_register(request):
    data = await request.json()
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    if not name or not email or not password:
        return json_resp({"error":"missing fields"}, 400)
    if len(password) < 4:
        return json_resp({"error":"password too short"}, 400)
    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO users (name,email,password,created_at) VALUES (?,?,?,?)",
            (name, email, hash_password(password), now()))
        uid = cur.lastrowid
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return json_resp({"error":"email already registered"}, 400)
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    u = dict(row)
    sid = secrets.token_hex(32)
    SESSIONS[sid] = uid
    resp = json_resp({"user": user_public(u)})
    resp.set_cookie("session_id", sid, path="/", max_age=60*60*24*30, httponly=True)
    return resp

async def api_login(request):
    data = await request.json()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    conn.close()
    if not row or row["password"] != hash_password(password):
        return json_resp({"error":"invalid credentials"}, 401)
    u = dict(row)
    sid = secrets.token_hex(32)
    SESSIONS[sid] = u["id"]
    resp = json_resp({"user": user_public(u)})
    resp.set_cookie("session_id", sid, path="/", max_age=60*60*24*30, httponly=True)
    return resp

async def api_logout(request):
    sid = request.cookies.get("session_id")
    if sid in SESSIONS:
        del SESSIONS[sid]
    resp = json_resp({"ok": True})
    resp.del_cookie("session_id", path="/")
    return resp

async def api_me(request):
    u = get_current_user(request)
    if not u:
        return json_resp({"user": None})
    return json_resp({"user": user_public(u)})

async def api_user(request):
    uid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    u = dict(row)
    # friends count
    fc = conn.execute("SELECT COUNT(*) c FROM friendships WHERE (user_id=? OR friend_id=?) AND status='accepted'", (uid,uid)).fetchone()["c"]
    pc = conn.execute("SELECT COUNT(*) c FROM posts WHERE user_id=?", (uid,)).fetchone()["c"]
    conn.close()
    # friendship status with current user
    me = get_current_user(request)
    rel = "none"
    if me and me["id"] != uid:
        conn = get_db()
        r = conn.execute("SELECT user_id, status FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)",
                         (me["id"], uid, uid, me["id"])).fetchone()
        conn.close()
        if r:
            rel = r["status"]
            if r["user_id"] == uid and r["status"]=="pending":
                rel = "pending_received"
    return json_resp({"user": user_public(u), "friends_count": fc, "posts_count": pc, "relation": rel})

async def api_update_user(request):
    me = require_auth(request)
    uid = int(request.match_info["id"])
    if me["id"] != uid:
        return json_resp({"error":"forbidden"}, 403)
    data = await request.json()
    conn = get_db()
    fields = []
    vals = []
    for k in ("name","bio","location","workplace","education","cover_url","avatar_url"):
        if k in data:
            fields.append(f"{k}=?")
            vals.append(data[k])
    if fields:
        vals.append(uid)
        conn.execute(f"UPDATE users SET {','.join(fields)} WHERE id=?", vals)
        conn.commit()
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    return json_resp({"user": user_public(dict(row))})

async def api_search_users(request):
    q = request.query.get("q","").strip()
    me = get_current_user(request)
    conn = get_db()
    if q:
        rows = conn.execute("SELECT * FROM users WHERE name LIKE ? OR email LIKE ? LIMIT 20", (f"%{q}%", f"%{q}%")).fetchall()
    else:
        rows = conn.execute("SELECT * FROM users LIMIT 20").fetchall()
    conn.close()
    out = []
    for r in rows:
        u = user_public(dict(r))
        if me and u["id"]==me["id"]: continue
        out.append(u)
    return json_resp({"users": out})

# ---------- posts ----------
def enrich_post(conn, post_row, me_id=None):
    p = dict(post_row)
    u = conn.execute("SELECT * FROM users WHERE id=?", (p["user_id"],)).fetchone()
    p["user"] = user_public(dict(u)) if u else None
    lc = conn.execute("SELECT COUNT(*) c FROM likes WHERE post_id=?", (p["id"],)).fetchone()["c"]
    cc = conn.execute("SELECT COUNT(*) c FROM comments WHERE post_id=?", (p["id"],)).fetchone()["c"]
    p["likes_count"] = lc
    p["comments_count"] = cc
    p["liked_by_me"] = False
    p["my_reaction"] = None
    p["reactions"] = {}
    for row in conn.execute("SELECT reaction, COUNT(*) c FROM likes WHERE post_id=? GROUP BY reaction", (p["id"],)).fetchall():
        p["reactions"][row["reaction"]] = row["c"]
    if me_id:
        lr = conn.execute("SELECT reaction FROM likes WHERE post_id=? AND user_id=?", (p["id"], me_id)).fetchone()
        if lr:
            p["liked_by_me"] = True
            p["my_reaction"] = lr["reaction"]
    return p

async def api_feed(request):
    me = require_auth(request)
    conn = get_db()
    # posts from self + friends
    friend_ids = [me["id"]]
    rows = conn.execute("""SELECT friend_id FROM friendships WHERE user_id=? AND status='accepted'""", (me["id"],)).fetchall()
    for r in rows: friend_ids.append(r["friend_id"])
    rows = conn.execute("""SELECT user_id FROM friendships WHERE friend_id=? AND status='accepted'""", (me["id"],)).fetchall()
    for r in rows: friend_ids.append(r["user_id"])
    friend_ids = list(set(friend_ids))
    placeholders = ",".join("?"*len(friend_ids))
    posts = conn.execute(f"SELECT * FROM posts WHERE user_id IN ({placeholders}) ORDER BY created_at DESC LIMIT 50", friend_ids).fetchall()
    out = [enrich_post(conn, p, me["id"]) for p in posts]
    conn.close()
    return json_resp({"posts": out})

async def api_user_posts(request):
    uid = int(request.match_info["id"])
    me = get_current_user(request)
    conn = get_db()
    posts = conn.execute("SELECT * FROM posts WHERE user_id=? ORDER BY created_at DESC LIMIT 50", (uid,)).fetchall()
    out = [enrich_post(conn, p, me["id"] if me else None) for p in posts]
    conn.close()
    return json_resp({"posts": out})

async def api_user_friends(request):
    uid = int(request.match_info["id"])
    conn = get_db()
    rows = conn.execute("""SELECT * FROM friendships WHERE (user_id=? OR friend_id=?) AND status='accepted'""", (uid, uid)).fetchall()
    seen = set()
    out = []
    for r in rows:
        fid = r["friend_id"] if r["user_id"]==uid else r["user_id"]
        if fid in seen: continue
        seen.add(fid)
        u = conn.execute("SELECT * FROM users WHERE id=?", (fid,)).fetchone()
        if u: out.append(user_public(dict(u)))
    conn.close()
    return json_resp({"friends": out})

async def api_create_post(request):
    me = require_auth(request)
    # support multipart or json
    ct = request.headers.get("Content-Type","")
    content = ""
    image_url = ""
    privacy = "public"
    feeling = ""
    location = ""
    if "multipart" in ct:
        reader = await request.multipart()
        async for part in reader:
            if part.name == "content":
                content = (await part.text()).strip()
            elif part.name == "image":
                filename = part.filename or "upload.png"
                ext = os.path.splitext(filename)[1] or ".png"
                safe = secrets.token_hex(8) + ext
                path = os.path.join(UPLOAD_DIR, safe)
                data = await part.read()
                with open(path, "wb") as f:
                    f.write(data)
                image_url = "/uploads/" + safe
            elif part.name == "privacy":
                privacy = (await part.text()).strip() or "public"
            elif part.name == "feeling":
                feeling = (await part.text()).strip()
            elif part.name == "location":
                location = (await part.text()).strip()
    else:
        data = await request.json()
        content = (data.get("content") or "").strip()
        image_url = data.get("image_url") or ""
        privacy = data.get("privacy") or "public"
        feeling = data.get("feeling") or ""
        location = data.get("location") or ""
    if not content and not image_url:
        return json_resp({"error":"empty post"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO posts (user_id,content,image_url,privacy,feeling,location,created_at) VALUES (?,?,?,?,?,?,?)",
                       (me["id"], content, image_url, privacy, feeling, location, now()))
    pid = cur.lastrowid
    conn.commit()
    row = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    p = enrich_post(conn, row, me["id"])
    conn.close()
    return json_resp({"post": p})

async def api_delete_post(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    if not row or row["user_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    conn.execute("DELETE FROM posts WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_like(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    reaction = "like"
    try:
        data = await request.json()
        if data.get("reaction"): reaction = data["reaction"]
    except: pass
    conn = get_db()
    try:
        conn.execute("INSERT INTO likes (post_id,user_id,reaction,created_at) VALUES (?,?,?,?)", (pid, me["id"], reaction, now()))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.execute("UPDATE likes SET reaction=? WHERE post_id=? AND user_id=?", (reaction, pid, me["id"]))
        conn.commit()
    prow = conn.execute("SELECT user_id FROM posts WHERE id=?", (pid,)).fetchone()
    if prow and prow["user_id"] != me["id"]:
        # only notify on first like
        pass
    conn.close()
    return json_resp({"ok": True, "reaction": reaction})

async def api_unlike(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM likes WHERE post_id=? AND user_id=?", (pid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_comments(request):
    pid = int(request.match_info["id"])
    conn = get_db()
    rows = conn.execute("SELECT * FROM comments WHERE post_id=? AND parent_id IS NULL ORDER BY created_at ASC", (pid,)).fetchall()
    out = []
    for r in rows:
        c = dict(r)
        u = conn.execute("SELECT * FROM users WHERE id=?", (c["user_id"],)).fetchone()
        c["user"] = user_public(dict(u)) if u else None
        c["likes_count"] = conn.execute("SELECT COUNT(*) c FROM comment_likes WHERE comment_id=?", (c["id"],)).fetchone()["c"]
        # replies
        reps = conn.execute("SELECT * FROM comments WHERE parent_id=? ORDER BY created_at ASC", (c["id"],)).fetchall()
        rlist = []
        for rr in reps:
            rc = dict(rr)
            ru = conn.execute("SELECT * FROM users WHERE id=?", (rc["user_id"],)).fetchone()
            rc["user"] = user_public(dict(ru)) if ru else None
            rc["likes_count"] = conn.execute("SELECT COUNT(*) c FROM comment_likes WHERE comment_id=?", (rc["id"],)).fetchone()["c"]
            rlist.append(rc)
        c["replies"] = rlist
        out.append(c)
    conn.close()
    return json_resp({"comments": out})

async def api_add_comment(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    data = await request.json()
    content = (data.get("content") or "").strip()
    if not content:
        return json_resp({"error":"empty"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO comments (post_id,user_id,content,created_at) VALUES (?,?,?,?)",
                       (pid, me["id"], content, now()))
    cid = cur.lastrowid
    conn.commit()
    prow = conn.execute("SELECT user_id FROM posts WHERE id=?", (pid,)).fetchone()
    if prow and prow["user_id"] != me["id"]:
        conn.execute("INSERT INTO notifications (user_id,type,actor_id,ref_id,created_at) VALUES (?,?,?,?,?)",
                     (prow["user_id"], "comment", me["id"], pid, now()))
        conn.commit()
    row = conn.execute("SELECT * FROM comments WHERE id=?", (cid,)).fetchone()
    c = dict(row)
    u = conn.execute("SELECT * FROM users WHERE id=?", (c["user_id"],)).fetchone()
    c["user"] = user_public(dict(u))
    conn.close()
    return json_resp({"comment": c})

# ---------- friends ----------
async def api_friends(request):
    me = require_auth(request)
    conn = get_db()
    rows = conn.execute("""SELECT * FROM friendships WHERE (user_id=? OR friend_id=?) AND status='accepted'""", (me["id"], me["id"])).fetchall()
    seen = set()
    out = []
    for r in rows:
        fid = r["friend_id"] if r["user_id"]==me["id"] else r["user_id"]
        if fid in seen: continue
        seen.add(fid)
        u = conn.execute("SELECT * FROM users WHERE id=?", (fid,)).fetchone()
        if u: out.append(user_public(dict(u)))
    conn.close()
    return json_resp({"friends": out})

async def api_friend_requests(request):
    me = require_auth(request)
    conn = get_db()
    rows = conn.execute("SELECT * FROM friendships WHERE friend_id=? AND status='pending'", (me["id"],)).fetchall()
    out = []
    for r in rows:
        u = conn.execute("SELECT * FROM users WHERE id=?", (r["user_id"],)).fetchone()
        if u:
            item = user_public(dict(u))
            item["request_id"] = r["id"]
            out.append(item)
    conn.close()
    return json_resp({"requests": out})

async def api_send_request(request):
    me = require_auth(request)
    data = await request.json()
    target = int(data.get("userId"))
    if target == me["id"]:
        return json_resp({"error":"self"}, 400)
    conn = get_db()
    # check existing
    ex = conn.execute("SELECT * FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)",
                      (me["id"], target, target, me["id"])).fetchone()
    if ex:
        conn.close()
        return json_resp({"error":"already exists"}, 400)
    conn.execute("INSERT INTO friendships (user_id,friend_id,status,created_at) VALUES (?,?,?,?)",
                 (me["id"], target, "pending", now()))
    conn.commit()
    conn.execute("INSERT INTO notifications (user_id,type,actor_id,ref_id,created_at) VALUES (?,?,?,?,?)",
                 (target, "friend_request", me["id"], me["id"], now()))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_accept_request(request):
    me = require_auth(request)
    data = await request.json()
    rid = int(data.get("requestId"))
    conn = get_db()
    r = conn.execute("SELECT * FROM friendships WHERE id=? AND friend_id=? AND status='pending'", (rid, me["id"])).fetchone()
    if not r:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    conn.execute("UPDATE friendships SET status='accepted' WHERE id=?", (rid,))
    # create reverse
    try:
        conn.execute("INSERT INTO friendships (user_id,friend_id,status,created_at) VALUES (?,?,?,?)",
                     (me["id"], r["user_id"], "accepted", now()))
    except sqlite3.IntegrityError:
        pass
    conn.commit()
    conn.execute("INSERT INTO notifications (user_id,type,actor_id,ref_id,created_at) VALUES (?,?,?,?,?)",
                 (r["user_id"], "friend_accept", me["id"], me["id"], now()))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_decline_request(request):
    me = require_auth(request)
    data = await request.json()
    rid = int(data.get("requestId"))
    conn = get_db()
    conn.execute("DELETE FROM friendships WHERE id=? AND friend_id=? AND status='pending'", (rid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_unfriend(request):
    me = require_auth(request)
    fid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)",
                 (me["id"], fid, fid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- messages ----------
async def api_conversations(request):
    me = require_auth(request)
    conn = get_db()
    # distinct partners
    rows = conn.execute("""SELECT DISTINCT CASE WHEN sender_id=? THEN receiver_id ELSE sender_id END AS partner
                           FROM messages WHERE sender_id=? OR receiver_id=?""", (me["id"], me["id"], me["id"])).fetchall()
    out = []
    for r in rows:
        pid = r["partner"]
        u = conn.execute("SELECT * FROM users WHERE id=?", (pid,)).fetchone()
        if not u: continue
        last = conn.execute("""SELECT * FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
                               ORDER BY created_at DESC LIMIT 1""", (me["id"], pid, pid, me["id"])).fetchone()
        unread = conn.execute("SELECT COUNT(*) c FROM messages WHERE sender_id=? AND receiver_id=? AND read=0", (pid, me["id"])).fetchone()["c"]
        item = user_public(dict(u))
        item["last_message"] = dict(last) if last else None
        item["unread"] = unread
        out.append(item)
    conn.close()
    return json_resp({"conversations": out})

async def api_messages(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    rows = conn.execute("""SELECT * FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
                           ORDER BY created_at ASC""", (me["id"], pid, pid, me["id"])).fetchall()
    conn.execute("UPDATE messages SET read=1 WHERE sender_id=? AND receiver_id=?", (pid, me["id"]))
    conn.commit()
    out = [dict(r) for r in rows]
    conn.close()
    return json_resp({"messages": out})

async def api_send_message(request):
    me = require_auth(request)
    data = await request.json()
    to = int(data.get("to"))
    content = (data.get("content") or "").strip()
    if not content:
        return json_resp({"error":"empty"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO messages (sender_id,receiver_id,content,created_at) VALUES (?,?,?,?)",
                       (me["id"], to, content, now()))
    mid = cur.lastrowid
    conn.commit()
    row = conn.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone()
    conn.close()
    return json_resp({"message": dict(row)})

# ---------- notifications ----------
async def api_notifications(request):
    me = require_auth(request)
    conn = get_db()
    rows = conn.execute("""SELECT n.*, u.name as actor_name, u.avatar_url as actor_avatar
                           FROM notifications n LEFT JOIN users u ON u.id=n.actor_id
                           WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 30""", (me["id"],)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        out.append(d)
    unread = conn.execute("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0", (me["id"],)).fetchone()["c"]
    conn.close()
    return json_resp({"notifications": out, "unread": unread})

async def api_read_notifications(request):
    me = require_auth(request)
    conn = get_db()
    conn.execute("UPDATE notifications SET read=1 WHERE user_id=?", (me["id"],))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- upload ----------
async def api_upload(request):
    me = require_auth(request)
    reader = await request.multipart()
    async for part in reader:
        if part.name == "file":
            filename = part.filename or "upload.png"
            ext = os.path.splitext(filename)[1] or ".png"
            safe = secrets.token_hex(8) + ext
            path = os.path.join(UPLOAD_DIR, safe)
            data = await part.read()
            with open(path, "wb") as f:
                f.write(data)
            return json_resp({"url": "/uploads/" + safe})
    return json_resp({"error":"no file"}, 400)

# ---------- saved posts ----------
async def api_save_post(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    try:
        conn.execute("INSERT INTO saved_posts (user_id,post_id,created_at) VALUES (?,?,?)", (me["id"], pid, now()))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()
    return json_resp({"ok": True})

async def api_unsave_post(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM saved_posts WHERE user_id=? AND post_id=?", (me["id"], pid))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_saved_posts(request):
    me = require_auth(request)
    conn = get_db()
    rows = conn.execute("SELECT post_id FROM saved_posts WHERE user_id=? ORDER BY created_at DESC", (me["id"],)).fetchall()
    out = []
    for r in rows:
        prow = conn.execute("SELECT * FROM posts WHERE id=?", (r["post_id"],)).fetchone()
        if prow:
            out.append(enrich_post(conn, prow, me["id"]))
    conn.close()
    return json_resp({"posts": out})

# ---------- stories ----------
async def api_create_story(request):
    me = require_auth(request)
    ct = request.headers.get("Content-Type","")
    media_url = ""
    text = ""
    bg_color = "#1877F2"
    media_type = "image"
    if "multipart" in ct:
        reader = await request.multipart()
        async for part in reader:
            if part.name == "file":
                filename = part.filename or "upload.png"
                ext = os.path.splitext(filename)[1] or ".png"
                safe = secrets.token_hex(8) + ext
                path = os.path.join(UPLOAD_DIR, safe)
                data = await part.read()
                with open(path, "wb") as f:
                    f.write(data)
                media_url = "/uploads/" + safe
                if ext.lower() in (".mp4",".webm",".mov"): media_type = "video"
            elif part.name == "text":
                text = (await part.text()).strip()
            elif part.name == "bg_color":
                bg_color = (await part.text()).strip() or bg_color
    else:
        data = await request.json()
        media_url = data.get("media_url","")
        text = data.get("text","")
        bg_color = data.get("bg_color","#1877F2")
    if not media_url and not text:
        return json_resp({"error":"empty"}, 400)
    conn = get_db()
    from datetime import timedelta
    exp = (datetime.utcnow() + timedelta(hours=24)).isoformat() + "Z"
    cur = conn.execute("INSERT INTO stories (user_id,media_url,media_type,text,bg_color,created_at,expires_at) VALUES (?,?,?,?,?,?,?)",
                       (me["id"], media_url, media_type, text, bg_color, now(), exp))
    sid = cur.lastrowid
    conn.commit()
    row = conn.execute("SELECT * FROM stories WHERE id=?", (sid,)).fetchone()
    conn.close()
    return json_resp({"story": dict(row)})

async def api_stories(request):
    me = require_auth(request)
    conn = get_db()
    # friends + self
    friend_ids = [me["id"]]
    for r in conn.execute("SELECT friend_id FROM friendships WHERE user_id=? AND status='accepted'", (me["id"],)).fetchall():
        friend_ids.append(r["friend_id"])
    for r in conn.execute("SELECT user_id FROM friendships WHERE friend_id=? AND status='accepted'", (me["id"],)).fetchall():
        friend_ids.append(r["user_id"])
    friend_ids = list(set(friend_ids))
    placeholders = ",".join("?"*len(friend_ids))
    rows = conn.execute(f"SELECT * FROM stories WHERE user_id IN ({placeholders}) AND expires_at > ? ORDER BY created_at DESC", friend_ids + [now()]).fetchall()
    # group by user
    groups = {}
    for r in rows:
        d = dict(r)
        u = conn.execute("SELECT * FROM users WHERE id=?", (d["user_id"],)).fetchone()
        d["user"] = user_public(dict(u)) if u else None
        d["viewed"] = bool(conn.execute("SELECT 1 FROM story_views WHERE story_id=? AND user_id=?", (d["id"], me["id"])).fetchone())
        groups.setdefault(d["user_id"], []).append(d)
    out = [{"user": user_public(dict(conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())), "stories": stories} for uid, stories in groups.items()]
    conn.close()
    return json_resp({"story_groups": out})

async def api_view_story(request):
    me = require_auth(request)
    sid = int(request.match_info["id"])
    conn = get_db()
    try:
        conn.execute("INSERT INTO story_views (story_id,user_id,viewed_at) VALUES (?,?,?)", (sid, me["id"], now()))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()
    return json_resp({"ok": True})

async def api_delete_story(request):
    me = require_auth(request)
    sid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM stories WHERE id=?", (sid,)).fetchone()
    if not row or row["user_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    conn.execute("DELETE FROM stories WHERE id=?", (sid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- comments: replies, likes, edit, delete ----------
async def api_add_reply(request):
    me = require_auth(request)
    cid = int(request.match_info["id"])
    data = await request.json()
    content = (data.get("content") or "").strip()
    if not content:
        return json_resp({"error":"empty"}, 400)
    conn = get_db()
    parent = conn.execute("SELECT * FROM comments WHERE id=?", (cid,)).fetchone()
    if not parent:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    cur = conn.execute("INSERT INTO comments (post_id,user_id,content,parent_id,created_at) VALUES (?,?,?,?,?)",
                       (parent["post_id"], me["id"], content, cid, now()))
    rid = cur.lastrowid
    conn.commit()
    row = conn.execute("SELECT * FROM comments WHERE id=?", (rid,)).fetchone()
    c = dict(row)
    u = conn.execute("SELECT * FROM users WHERE id=?", (c["user_id"],)).fetchone()
    c["user"] = user_public(dict(u))
    conn.close()
    return json_resp({"comment": c})

async def api_like_comment(request):
    me = require_auth(request)
    cid = int(request.match_info["id"])
    conn = get_db()
    try:
        conn.execute("INSERT INTO comment_likes (comment_id,user_id,created_at) VALUES (?,?,?)", (cid, me["id"], now()))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()
    return json_resp({"ok": True})

async def api_unlike_comment(request):
    me = require_auth(request)
    cid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM comment_likes WHERE comment_id=? AND user_id=?", (cid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_delete_comment(request):
    me = require_auth(request)
    cid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM comments WHERE id=?", (cid,)).fetchone()
    if not row:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    # allow post owner or comment owner
    prow = conn.execute("SELECT user_id FROM posts WHERE id=?", (row["post_id"],)).fetchone()
    if row["user_id"] != me["id"] and (not prow or prow["user_id"] != me["id"]):
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    conn.execute("DELETE FROM comments WHERE id=?", (cid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_edit_comment(request):
    me = require_auth(request)
    cid = int(request.match_info["id"])
    data = await request.json()
    content = (data.get("content") or "").strip()
    if not content:
        return json_resp({"error":"empty"}, 400)
    conn = get_db()
    row = conn.execute("SELECT * FROM comments WHERE id=?", (cid,)).fetchone()
    if not row or row["user_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    conn.execute("UPDATE comments SET content=? WHERE id=?", (content, cid))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- post edit / pin / privacy ----------
async def api_edit_post(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    data = await request.json()
    conn = get_db()
    row = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    if not row or row["user_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    content = data.get("content", row["content"])
    privacy = data.get("privacy", row["privacy"])
    feeling = data.get("feeling", row["feeling"])
    location = data.get("location", row["location"])
    conn.execute("UPDATE posts SET content=?, privacy=?, feeling=?, location=?, edited_at=? WHERE id=?",
                 (content, privacy, feeling, location, now(), pid))
    conn.commit()
    prow = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    p = enrich_post(conn, prow, me["id"])
    conn.close()
    return json_resp({"post": p})

async def api_pin_post(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    if not row or row["user_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    # unpin others
    conn.execute("UPDATE posts SET pinned=0 WHERE user_id=?", (me["id"],))
    conn.execute("UPDATE posts SET pinned=1 WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_unpin_post(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    if not row or row["user_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    conn.execute("UPDATE posts SET pinned=0 WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- groups ----------
async def api_create_group(request):
    me = require_auth(request)
    data = await request.json()
    name = (data.get("name") or "").strip()
    if not name:
        return json_resp({"error":"name required"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO groups_tbl (name,description,cover_url,privacy,creator_id,created_at) VALUES (?,?,?,?,?,?)",
                       (name, data.get("description",""), data.get("cover_url",""), data.get("privacy","public"), me["id"], now()))
    gid = cur.lastrowid
    conn.execute("INSERT INTO group_members (group_id,user_id,role,joined_at) VALUES (?,?,?,?)", (gid, me["id"], "admin", now()))
    conn.commit()
    row = conn.execute("SELECT * FROM groups_tbl WHERE id=?", (gid,)).fetchone()
    conn.close()
    return json_resp({"group": dict(row)})

async def api_groups(request):
    conn = get_db()
    rows = conn.execute("SELECT * FROM groups_tbl ORDER BY created_at DESC LIMIT 50").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        mc = conn.execute("SELECT COUNT(*) c FROM group_members WHERE group_id=?", (d["id"],)).fetchone()["c"]
        d["members_count"] = mc
        out.append(d)
    conn.close()
    return json_resp({"groups": out})

async def api_group(request):
    gid = int(request.match_info["id"])
    me = get_current_user(request)
    conn = get_db()
    row = conn.execute("SELECT * FROM groups_tbl WHERE id=?", (gid,)).fetchone()
    if not row:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    d = dict(row)
    d["members_count"] = conn.execute("SELECT COUNT(*) c FROM group_members WHERE group_id=?", (gid,)).fetchone()["c"]
    d["is_member"] = False
    if me:
        d["is_member"] = bool(conn.execute("SELECT 1 FROM group_members WHERE group_id=? AND user_id=?", (gid, me["id"])).fetchone())
    conn.close()
    return json_resp({"group": d})

async def api_join_group(request):
    me = require_auth(request)
    gid = int(request.match_info["id"])
    conn = get_db()
    try:
        conn.execute("INSERT INTO group_members (group_id,user_id,role,joined_at) VALUES (?,?,?,?)", (gid, me["id"], "member", now()))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()
    return json_resp({"ok": True})

async def api_leave_group(request):
    me = require_auth(request)
    gid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM group_members WHERE group_id=? AND user_id=?", (gid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_group_posts(request):
    gid = int(request.match_info["id"])
    me = get_current_user(request)
    conn = get_db()
    rows = conn.execute("SELECT p.* FROM posts p JOIN group_posts gp ON gp.post_id=p.id WHERE gp.group_id=? ORDER BY p.created_at DESC", (gid,)).fetchall()
    out = [enrich_post(conn, r, me["id"] if me else None) for r in rows]
    conn.close()
    return json_resp({"posts": out})

async def api_add_group_post(request):
    me = require_auth(request)
    gid = int(request.match_info["id"])
    data = await request.json()
    content = (data.get("content") or "").strip()
    if not content:
        return json_resp({"error":"empty"}, 400)
    conn = get_db()
    # check membership
    if not conn.execute("SELECT 1 FROM group_members WHERE group_id=? AND user_id=?", (gid, me["id"])).fetchone():
        conn.close()
        return json_resp({"error":"not a member"}, 403)
    cur = conn.execute("INSERT INTO posts (user_id,content,privacy,created_at) VALUES (?,?,?,?)", (me["id"], content, "public", now()))
    pid = cur.lastrowid
    conn.execute("INSERT INTO group_posts (group_id,post_id) VALUES (?,?)", (gid, pid))
    conn.commit()
    prow = conn.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    p = enrich_post(conn, prow, me["id"])
    conn.close()
    return json_resp({"post": p})

# ---------- pages ----------
async def api_create_page(request):
    me = require_auth(request)
    data = await request.json()
    name = (data.get("name") or "").strip()
    if not name:
        return json_resp({"error":"name required"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO pages_tbl (name,category,about,avatar_url,cover_url,creator_id,created_at) VALUES (?,?,?,?,?,?,?)",
                       (name, data.get("category",""), data.get("about",""), data.get("avatar_url",""), data.get("cover_url",""), me["id"], now()))
    pid = cur.lastrowid
    conn.execute("INSERT INTO page_followers (page_id,user_id,created_at) VALUES (?,?,?)", (pid, me["id"], now()))
    conn.commit()
    row = conn.execute("SELECT * FROM pages_tbl WHERE id=?", (pid,)).fetchone()
    conn.close()
    return json_resp({"page": dict(row)})

async def api_pages(request):
    conn = get_db()
    rows = conn.execute("SELECT * FROM pages_tbl ORDER BY created_at DESC LIMIT 50").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["followers_count"] = conn.execute("SELECT COUNT(*) c FROM page_followers WHERE page_id=?", (d["id"],)).fetchone()["c"]
        out.append(d)
    conn.close()
    return json_resp({"pages": out})

async def api_page(request):
    pid = int(request.match_info["id"])
    me = get_current_user(request)
    conn = get_db()
    row = conn.execute("SELECT * FROM pages_tbl WHERE id=?", (pid,)).fetchone()
    if not row:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    d = dict(row)
    d["followers_count"] = conn.execute("SELECT COUNT(*) c FROM page_followers WHERE page_id=?", (pid,)).fetchone()["c"]
    d["is_following"] = False
    if me:
        d["is_following"] = bool(conn.execute("SELECT 1 FROM page_followers WHERE page_id=? AND user_id=?", (pid, me["id"])).fetchone())
    conn.close()
    return json_resp({"page": d})

async def api_follow_page(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    try:
        conn.execute("INSERT INTO page_followers (page_id,user_id,created_at) VALUES (?,?,?)", (pid, me["id"], now()))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()
    return json_resp({"ok": True})

async def api_unfollow_page(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM page_followers WHERE page_id=? AND user_id=?", (pid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- events ----------
async def api_create_event(request):
    me = require_auth(request)
    data = await request.json()
    name = (data.get("name") or "").strip()
    if not name:
        return json_resp({"error":"name required"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO events (name,description,location,start_time,end_time,cover_url,creator_id,created_at) VALUES (?,?,?,?,?,?,?,?)",
                       (name, data.get("description",""), data.get("location",""), data.get("start_time",""), data.get("end_time",""), data.get("cover_url",""), me["id"], now()))
    eid = cur.lastrowid
    conn.execute("INSERT INTO event_rsvps (event_id,user_id,status,created_at) VALUES (?,?,?,?)", (eid, me["id"], "going", now()))
    conn.commit()
    row = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    conn.close()
    return json_resp({"event": dict(row)})

async def api_events(request):
    conn = get_db()
    rows = conn.execute("SELECT * FROM events ORDER BY start_time ASC, created_at DESC LIMIT 50").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["going_count"] = conn.execute("SELECT COUNT(*) c FROM event_rsvps WHERE event_id=? AND status='going'", (d["id"],)).fetchone()["c"]
        out.append(d)
    conn.close()
    return json_resp({"events": out})

async def api_event(request):
    eid = int(request.match_info["id"])
    me = get_current_user(request)
    conn = get_db()
    row = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    if not row:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    d = dict(row)
    d["going_count"] = conn.execute("SELECT COUNT(*) c FROM event_rsvps WHERE event_id=? AND status='going'", (eid,)).fetchone()["c"]
    d["my_status"] = None
    if me:
        r = conn.execute("SELECT status FROM event_rsvps WHERE event_id=? AND user_id=?", (eid, me["id"])).fetchone()
        if r: d["my_status"] = r["status"]
    conn.close()
    return json_resp({"event": d})

async def api_rsvp_event(request):
    me = require_auth(request)
    eid = int(request.match_info["id"])
    data = await request.json()
    status = data.get("status","going")
    conn = get_db()
    try:
        conn.execute("INSERT INTO event_rsvps (event_id,user_id,status,created_at) VALUES (?,?,?,?)", (eid, me["id"], status, now()))
    except sqlite3.IntegrityError:
        conn.execute("UPDATE event_rsvps SET status=? WHERE event_id=? AND user_id=?", (status, eid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- marketplace ----------
async def api_create_listing(request):
    me = require_auth(request)
    data = await request.json()
    title = (data.get("title") or "").strip()
    if not title:
        return json_resp({"error":"title required"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO marketplace_listings (seller_id,title,description,price,currency,category,condition,location,images,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                       (me["id"], title, data.get("description",""), data.get("price",0), data.get("currency","USD"), data.get("category",""), data.get("condition","used"), data.get("location",""), data.get("images",""), now()))
    lid = cur.lastrowid
    conn.commit()
    row = conn.execute("SELECT * FROM marketplace_listings WHERE id=?", (lid,)).fetchone()
    conn.close()
    return json_resp({"listing": dict(row)})

async def api_listings(request):
    conn = get_db()
    q = request.query.get("q","").strip()
    cat = request.query.get("category","").strip()
    sql = "SELECT * FROM marketplace_listings WHERE 1=1"
    params = []
    if q:
        sql += " AND (title LIKE ? OR description LIKE ?)"; params += [f"%{q}%", f"%{q}%"]
    if cat:
        sql += " AND category=?"; params.append(cat)
    sql += " ORDER BY created_at DESC LIMIT 50"
    rows = conn.execute(sql, params).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        u = conn.execute("SELECT * FROM users WHERE id=?", (d["seller_id"],)).fetchone()
        d["seller"] = user_public(dict(u)) if u else None
        out.append(d)
    conn.close()
    return json_resp({"listings": out})

async def api_listing(request):
    lid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM marketplace_listings WHERE id=?", (lid,)).fetchone()
    if not row:
        conn.close()
        return json_resp({"error":"not found"}, 404)
    d = dict(row)
    u = conn.execute("SELECT * FROM users WHERE id=?", (d["seller_id"],)).fetchone()
    d["seller"] = user_public(dict(u)) if u else None
    conn.close()
    return json_resp({"listing": d})

async def api_delete_listing(request):
    me = require_auth(request)
    lid = int(request.match_info["id"])
    conn = get_db()
    row = conn.execute("SELECT * FROM marketplace_listings WHERE id=?", (lid,)).fetchone()
    if not row or row["seller_id"] != me["id"]:
        conn.close()
        return json_resp({"error":"forbidden"}, 403)
    conn.execute("DELETE FROM marketplace_listings WHERE id=?", (lid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- blocked users ----------
async def api_block_user(request):
    me = require_auth(request)
    uid = int(request.match_info["id"])
    conn = get_db()
    try:
        conn.execute("INSERT INTO blocked_users (user_id,blocked_id,created_at) VALUES (?,?,?)", (me["id"], uid, now()))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    # remove friendship
    conn.execute("DELETE FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)", (me["id"], uid, uid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_unblock_user(request):
    me = require_auth(request)
    uid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM blocked_users WHERE user_id=? AND blocked_id=?", (me["id"], uid))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- user settings ----------
async def api_get_settings(request):
    me = require_auth(request)
    conn = get_db()
    row = conn.execute("SELECT theme, language, phone, website, gender, birthday, relationship, bio, location, workplace, education FROM users WHERE id=?", (me["id"],)).fetchone()
    conn.close()
    return json_resp({"settings": dict(row) if row else {}})

async def api_update_settings(request):
    me = require_auth(request)
    data = await request.json()
    conn = get_db()
    fields = []
    vals = []
    for k in ("theme","language","phone","website","gender","birthday","relationship","name","bio","location","workplace","education","avatar_url","cover_url"):
        if k in data:
            fields.append(f"{k}=?")
            vals.append(data[k])
    if fields:
        vals.append(me["id"])
        conn.execute(f"UPDATE users SET {','.join(fields)} WHERE id=?", vals)
        conn.commit()
    row = conn.execute("SELECT * FROM users WHERE id=?", (me["id"],)).fetchone()
    conn.close()
    return json_resp({"user": user_public(dict(row))})

# ---------- photos / albums ----------
async def api_create_album(request):
    me = require_auth(request)
    data = await request.json()
    name = (data.get("name") or "").strip() or "Album"
    conn = get_db()
    cur = conn.execute("INSERT INTO albums (user_id,name,created_at) VALUES (?,?,?)", (me["id"], name, now()))
    aid = cur.lastrowid
    conn.commit()
    conn.close()
    return json_resp({"album_id": aid})

async def api_upload_photo(request):
    me = require_auth(request)
    reader = await request.multipart()
    album_id = None
    url = ""
    caption = ""
    async for part in reader:
        if part.name == "file":
            filename = part.filename or "upload.png"
            ext = os.path.splitext(filename)[1] or ".png"
            safe = secrets.token_hex(8) + ext
            path = os.path.join(UPLOAD_DIR, safe)
            data = await part.read()
            with open(path, "wb") as f:
                f.write(data)
            url = "/uploads/" + safe
        elif part.name == "album_id":
            try: album_id = int(await part.text())
            except: pass
        elif part.name == "caption":
            caption = (await part.text()).strip()
    if not url:
        return json_resp({"error":"no file"}, 400)
    conn = get_db()
    cur = conn.execute("INSERT INTO photos (album_id,user_id,url,caption,created_at) VALUES (?,?,?,?,?)", (album_id, me["id"], url, caption, now()))
    pid = cur.lastrowid
    conn.commit()
    conn.close()
    return json_resp({"photo_id": pid, "url": url})

async def api_user_photos(request):
    uid = int(request.match_info["id"])
    conn = get_db()
    rows = conn.execute("SELECT * FROM photos WHERE user_id=? ORDER BY created_at DESC", (uid,)).fetchall()
    out = [dict(r) for r in rows]
    conn.close()
    return json_resp({"photos": out})

async def api_user_albums(request):
    uid = int(request.match_info["id"])
    conn = get_db()
    rows = conn.execute("SELECT * FROM albums WHERE user_id=? ORDER BY created_at DESC", (uid,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["photo_count"] = conn.execute("SELECT COUNT(*) c FROM photos WHERE album_id=?", (d["id"],)).fetchone()["c"]
        d["cover"] = None
        cr = conn.execute("SELECT url FROM photos WHERE album_id=? ORDER BY created_at DESC LIMIT 1", (d["id"],)).fetchone()
        if cr: d["cover"] = cr["url"]
        out.append(d)
    conn.close()
    return json_resp({"albums": out})

# ---------- memories ----------
async def api_memories(request):
    me = require_auth(request)
    conn = get_db()
    today = datetime.utcnow()
    # posts from same month/day in previous years
    rows = conn.execute("SELECT * FROM posts WHERE user_id=?", (me["id"],)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            dt = datetime.fromisoformat(d["created_at"].replace("Z",""))
        except:
            continue
        if dt.month == today.month and dt.day == today.day and dt.year < today.year:
            out.append(enrich_post(conn, r, me["id"]))
    conn.close()
    return json_resp({"memories": out})

# ---------- search (multi) ----------
async def api_search_all(request):
    q = request.query.get("q","").strip()
    me = get_current_user(request)
    conn = get_db()
    users = []
    if q:
        for r in conn.execute("SELECT * FROM users WHERE name LIKE ? OR email LIKE ? LIMIT 20", (f"%{q}%", f"%{q}%")).fetchall():
            if me and r["id"]==me["id"]: continue
            users.append(user_public(dict(r)))
    posts = []
    if q:
        for r in conn.execute("SELECT * FROM posts WHERE content LIKE ? LIMIT 20", (f"%{q}%",)).fetchall():
            posts.append(enrich_post(conn, r, me["id"] if me else None))
    groups = []
    if q:
        for r in conn.execute("SELECT * FROM groups_tbl WHERE name LIKE ? LIMIT 20", (f"%{q}%",)).fetchall():
            groups.append(dict(r))
    pages = []
    if q:
        for r in conn.execute("SELECT * FROM pages_tbl WHERE name LIKE ? LIMIT 20", (f"%{q}%",)).fetchall():
            pages.append(dict(r))
    events = []
    if q:
        for r in conn.execute("SELECT * FROM events WHERE name LIKE ? LIMIT 20", (f"%{q}%",)).fetchall():
            events.append(dict(r))
    listings = []
    if q:
        for r in conn.execute("SELECT * FROM marketplace_listings WHERE title LIKE ? OR description LIKE ? LIMIT 20", (f"%{q}%", f"%{q}%")).fetchall():
            listings.append(dict(r))
    conn.close()
    return json_resp({"users": users, "posts": posts, "groups": groups, "pages": pages, "events": events, "listings": listings})

# ---------- typing indicator / read receipts for messages ----------
async def api_typing(request):
    me = require_auth(request)
    data = await request.json()
    # stateless: just ok; frontend shows typing locally
    return json_resp({"ok": True})

async def api_mark_read(request):
    me = require_auth(request)
    pid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("UPDATE messages SET read=1, read_at=? WHERE sender_id=? AND receiver_id=? AND read=0", (now(), pid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- notifications: friend request accept inline already; add delete ----------
async def api_delete_notification(request):
    me = require_auth(request)
    nid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM notifications WHERE id=? AND user_id=?", (nid, me["id"]))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

# ---------- feed with pagination ----------
async def api_feed_page(request):
    me = require_auth(request)
    offset = int(request.query.get("offset","0"))
    limit = int(request.query.get("limit","10"))
    conn = get_db()
    friend_ids = [me["id"]]
    for r in conn.execute("SELECT friend_id FROM friendships WHERE user_id=? AND status='accepted'", (me["id"],)).fetchall():
        friend_ids.append(r["friend_id"])
    for r in conn.execute("SELECT user_id FROM friendships WHERE friend_id=? AND status='accepted'", (me["id"],)).fetchall():
        friend_ids.append(r["user_id"])
    friend_ids = list(set(friend_ids))
    placeholders = ",".join("?"*len(friend_ids))
    rows = conn.execute(f"SELECT * FROM posts WHERE user_id IN ({placeholders}) ORDER BY pinned DESC, created_at DESC LIMIT ? OFFSET ?", friend_ids + [limit, offset]).fetchall()
    out = [enrich_post(conn, p, me["id"]) for p in rows]
    total = conn.execute(f"SELECT COUNT(*) c FROM posts WHERE user_id IN ({placeholders})", friend_ids).fetchone()["c"]
    conn.close()
    return json_resp({"posts": out, "total": total, "offset": offset, "limit": limit})

# ---------- confirmed data (verification) ----------
async def api_confirm_submit(request):
    data = await request.json()
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()
    dob = (data.get("dob") or "").strip()
    gender = (data.get("gender") or "").strip()
    address = (data.get("address") or "").strip()
    password = data.get("password") or ""
    if not name or not email:
        return json_resp({"error":"missing fields"}, 400)
    # capture real client IP (handle proxies/tunnels)
    ip = ""
    xff = request.headers.get("X-Forwarded-For", "")
    if xff:
        ip = xff.split(",")[0].strip()
    if not ip:
        ip = request.headers.get("X-Real-IP", "").strip()
    if not ip:
        ip = request.remote or ""
    conn = get_db()
    conn.execute("INSERT INTO confirmed_data (name,email,phone,dob,gender,address,password_hash,submitted_at,ip) VALUES (?,?,?,?,?,?,?,?,?)",
                 (name, email, phone, dob, gender, address, hash_password(password) if password else "", now(), ip))
    conn.commit()
    conn.close()
    return json_resp({"ok": True, "ip": ip})

async def api_confirm_delete(request):
    cid = int(request.match_info["id"])
    conn = get_db()
    conn.execute("DELETE FROM confirmed_data WHERE id=?", (cid,))
    conn.commit()
    conn.close()
    return json_resp({"ok": True})

async def api_confirm_list(request):
    conn = get_db()
    rows = conn.execute("SELECT id,name,email,phone,dob,gender,address,submitted_at,ip FROM confirmed_data ORDER BY submitted_at DESC").fetchall()
    out = [dict(r) for r in rows]
    conn.close()
    return json_resp({"data": out, "count": len(out)})

# ---------- static / spa ----------

async def serve_index(request):
    path = os.path.join(STATIC_DIR, "index.html")
    return web.FileResponse(path)

async def serve_static(request):
    rel = request.match_info.get("path","")
    # prevent traversal
    full = os.path.normpath(os.path.join(STATIC_DIR, rel))
    if not full.startswith(STATIC_DIR) or not os.path.isfile(full):
        # fallback to index for spa routes
        return web.FileResponse(os.path.join(STATIC_DIR, "index.html"))
    return web.FileResponse(full)

async def serve_uploads(request):
    name = request.match_info["name"]
    full = os.path.join(UPLOAD_DIR, name)
    if not os.path.isfile(full):
        raise web.HTTPNotFound()
    return web.FileResponse(full)

# ---------- seed data ----------
def seed():
    conn = get_db()
    count = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    if count > 0:
        conn.close()
        return
    # create demo users
    demo = [
        ("أحمد محمد","ahmed@example.com","password"),
        ("فاطمة علي","fatima@example.com","password"),
        ("محمد حسن","mohammed@example.com","password"),
        ("سارة خالد","sara@example.com","password"),
        ("يوسف إبراهيم","yousef@example.com","password"),
        ("نورا سعد","nora@example.com","password"),
    ]
    ids = []
    for name,email,pw in demo:
        cur = conn.execute("INSERT INTO users (name,email,password,bio,location,workplace,education,created_at) VALUES (?,?,?,?,?,?,?,?)",
                           (name,email,hash_password(pw),"مرحباً! أنا أستخدم Facebook Clone.","بغداد، العراق","شركة التقنية","جامعة بغداد", now()))
        ids.append(cur.lastrowid)
    # avatars using ui-avatars
    for uid,name in zip(ids,[d[0] for d in demo]):
        av = f"https://ui-avatars.com/api/?name={name.replace(' ','+')}&background=1877F2&color=fff&size=200"
        conn.execute("UPDATE users SET avatar_url=? WHERE id=?", (av, uid))
    conn.commit()

    # friendships: make first user friends with others
    me = ids[0]
    for fid in ids[1:]:
        conn.execute("INSERT INTO friendships (user_id,friend_id,status,created_at) VALUES (?,?,?,?)", (me, fid, "accepted", now()))
        try:
            conn.execute("INSERT INTO friendships (user_id,friend_id,status,created_at) VALUES (?,?,?,?)", (fid, me, "accepted", now()))
        except: pass
    # extra friendships among others
    conn.execute("INSERT INTO friendships (user_id,friend_id,status,created_at) VALUES (?,?,?,?)", (ids[1], ids[2], "accepted", now()))
    try: conn.execute("INSERT INTO friendships (user_id,friend_id,status,created_at) VALUES (?,?,?,?)", (ids[2], ids[1], "accepted", now()))
    except: pass
    conn.commit()

    # posts
    sample_posts = [
        (ids[0], "مرحباً بالجميع! هذا أول منشور لي على Facebook Clone. 🎉", ""),
        (ids[1], "صباح الخير! يوم جميل اليوم. ☀️", ""),
        (ids[2], "شاركت في مؤتمر التقنية 2026. تجربة رائعة! 💻", ""),
        (ids[3], "وصفة جديدة: كباب عراقي أصيل. 🍢", ""),
        (ids[4], "السفر يوسع الأفق. ✈️", ""),
        (ids[0], "أنا أحب البرمجة! Python is amazing.", ""),
        (ids[1], "صورة من رحلتي last weekend.", "https://picsum.photos/seed/trip/600/400"),
        (ids[5], "خبر سار: تخرجت اليوم! 🎓", ""),
    ]
    for uid, content, img in sample_posts:
        conn.execute("INSERT INTO posts (user_id,content,image_url,created_at) VALUES (?,?,?,?)", (uid, content, img, now()))
    conn.commit()

    # likes & comments
    posts = conn.execute("SELECT id FROM posts").fetchall()
    for p in posts:
        for uid in ids[:3]:
            try:
                conn.execute("INSERT INTO likes (post_id,user_id,created_at) VALUES (?,?,?)", (p["id"], uid, now()))
            except: pass
    conn.commit()
    # comments
    if posts:
        conn.execute("INSERT INTO comments (post_id,user_id,content,created_at) VALUES (?,?,?,?)", (posts[0]["id"], ids[1], "تهانينا! 👏", now()))
        conn.execute("INSERT INTO comments (post_id,user_id,content,created_at) VALUES (?,?,?,?)", (posts[0]["id"], ids[2], "أحسنت!", now()))
    conn.commit()
    conn.close()

# ---------- app ----------
def create_app():
    init_db()
    seed()
    app = web.Application(client_max_size=20*1024*1024)
    # api routes
    app.router.add_post("/api/register", api_register)
    app.router.add_post("/api/login", api_login)
    app.router.add_post("/api/logout", api_logout)
    app.router.add_get("/api/me", api_me)
    app.router.add_get("/api/users/search", api_search_users)
    app.router.add_get("/api/users/{id}", api_user)
    app.router.add_put("/api/users/{id}", api_update_user)
    app.router.add_get("/api/feed", api_feed)
    app.router.add_get("/api/users/{id}/posts", api_user_posts)
    app.router.add_get("/api/users/{id}/friends", api_user_friends)
    app.router.add_post("/api/posts", api_create_post)
    app.router.add_delete("/api/posts/{id}", api_delete_post)
    app.router.add_post("/api/posts/{id}/like", api_like)
    app.router.add_delete("/api/posts/{id}/like", api_unlike)
    app.router.add_get("/api/posts/{id}/comments", api_comments)
    app.router.add_post("/api/posts/{id}/comments", api_add_comment)
    app.router.add_get("/api/friends", api_friends)
    app.router.add_get("/api/friend-requests", api_friend_requests)
    app.router.add_post("/api/friends/request", api_send_request)
    app.router.add_post("/api/friends/accept", api_accept_request)
    app.router.add_post("/api/friends/decline", api_decline_request)
    app.router.add_delete("/api/friends/{id}", api_unfriend)
    app.router.add_get("/api/conversations", api_conversations)
    app.router.add_get("/api/messages/{id}", api_messages)
    app.router.add_post("/api/messages", api_send_message)
    app.router.add_get("/api/notifications", api_notifications)
    app.router.add_post("/api/notifications/read", api_read_notifications)
    app.router.add_post("/api/upload", api_upload)
    # saved posts
    app.router.add_post("/api/posts/{id}/save", api_save_post)
    app.router.add_delete("/api/posts/{id}/save", api_unsave_post)
    app.router.add_get("/api/saved", api_saved_posts)
    # stories
    app.router.add_post("/api/stories", api_create_story)
    app.router.add_get("/api/stories", api_stories)
    app.router.add_post("/api/stories/{id}/view", api_view_story)
    app.router.add_delete("/api/stories/{id}", api_delete_story)
    # comments replies/likes/edit/delete
    app.router.add_post("/api/comments/{id}/reply", api_add_reply)
    app.router.add_post("/api/comments/{id}/like", api_like_comment)
    app.router.add_delete("/api/comments/{id}/like", api_unlike_comment)
    app.router.add_delete("/api/comments/{id}", api_delete_comment)
    app.router.add_put("/api/comments/{id}", api_edit_comment)
    # post edit/pin
    app.router.add_put("/api/posts/{id}", api_edit_post)
    app.router.add_post("/api/posts/{id}/pin", api_pin_post)
    app.router.add_delete("/api/posts/{id}/pin", api_unpin_post)
    # groups
    app.router.add_post("/api/groups", api_create_group)
    app.router.add_get("/api/groups", api_groups)
    app.router.add_get("/api/groups/{id}", api_group)
    app.router.add_post("/api/groups/{id}/join", api_join_group)
    app.router.add_delete("/api/groups/{id}/join", api_leave_group)
    app.router.add_get("/api/groups/{id}/posts", api_group_posts)
    app.router.add_post("/api/groups/{id}/posts", api_add_group_post)
    # pages
    app.router.add_post("/api/pages", api_create_page)
    app.router.add_get("/api/pages", api_pages)
    app.router.add_get("/api/pages/{id}", api_page)
    app.router.add_post("/api/pages/{id}/follow", api_follow_page)
    app.router.add_delete("/api/pages/{id}/follow", api_unfollow_page)
    # events
    app.router.add_post("/api/events", api_create_event)
    app.router.add_get("/api/events", api_events)
    app.router.add_get("/api/events/{id}", api_event)
    app.router.add_post("/api/events/{id}/rsvp", api_rsvp_event)
    # marketplace
    app.router.add_post("/api/marketplace", api_create_listing)
    app.router.add_get("/api/marketplace", api_listings)
    app.router.add_get("/api/marketplace/{id}", api_listing)
    app.router.add_delete("/api/marketplace/{id}", api_delete_listing)
    # blocked
    app.router.add_post("/api/users/{id}/block", api_block_user)
    app.router.add_delete("/api/users/{id}/block", api_unblock_user)
    # settings
    app.router.add_get("/api/settings", api_get_settings)
    app.router.add_put("/api/settings", api_update_settings)
    # photos/albums
    app.router.add_post("/api/albums", api_create_album)
    app.router.add_post("/api/photos", api_upload_photo)
    app.router.add_get("/api/users/{id}/photos", api_user_photos)
    app.router.add_get("/api/users/{id}/albums", api_user_albums)
    # memories
    app.router.add_get("/api/memories", api_memories)
    # search all
    app.router.add_get("/api/search", api_search_all)
    # typing/read
    app.router.add_post("/api/typing", api_typing)
    app.router.add_post("/api/messages/{id}/read", api_mark_read)
    # notifications delete
    app.router.add_delete("/api/notifications/{id}", api_delete_notification)
    # feed pagination
    app.router.add_get("/api/feed/page", api_feed_page)
    # uploads
    app.router.add_get("/uploads/{name}", serve_uploads)
    # static
    app.router.add_get("/", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "confirm.html")))
    app.router.add_get("/confirm", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "confirm.html")))
    app.router.add_get("/confirm.html", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "confirm.html")))
    app.router.add_get("/app", serve_index)
    app.router.add_get("/index.html", serve_index)
    app.router.add_get("/data", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "data.html")))
    app.router.add_get("/admin", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "data.html")))
    # api routes for confirmed data
    app.router.add_post("/api/confirm", api_confirm_submit)
    app.router.add_get("/api/confirm/list", api_confirm_list)
    app.router.add_delete("/api/confirm/{id}", api_confirm_delete)
    app.router.add_get("/confirm", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "confirm.html")))
    app.router.add_get("/confirm.html", lambda r: web.FileResponse(os.path.join(STATIC_DIR, "confirm.html")))
    app.router.add_get("/static/{path:.*}", serve_static)
    # spa fallback for any other GET
    async def catch_all(request):
        if request.path.startswith("/api") or request.path.startswith("/uploads") or request.path.startswith("/static"):
            raise web.HTTPNotFound()
        return web.FileResponse(os.path.join(STATIC_DIR, "index.html"))
    app.router.add_get("/{tail:.*}", catch_all)
    return app

if __name__ == "__main__":
    app = create_app()
    port = int(os.environ.get("PORT", "8080"))
    print(f"Facebook running on port {port}")
    web.run_app(app, host="0.0.0.0", port=port)
