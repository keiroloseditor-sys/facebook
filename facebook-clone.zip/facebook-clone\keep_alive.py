import subprocess, time, os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
SERVER_CMD = [sys.executable, "server.py"]
TUNNEL_CMD = ["ssh", "-i", os.path.expanduser("~/.ssh/id_rsa"), "-o", "StrictHostKeyChecking=no",
              "-o", "UserKnownHostsFile=NUL", "-T", "-R", "80:127.0.0.1:8080", "nokey@localhost.run"]

def start(proc_list, cmd, cwd=BASE, out=None):
    kwargs = {"cwd": cwd}
    if out:
        kwargs["stdout"] = open(out, "a")
        kwargs["stderr"] = subprocess.STDOUT
    return subprocess.Popen(cmd, **kwargs)

print("Keep-alive started. Press Ctrl+C to stop.")
server = None
tunnel = None
while True:
    if server is None or server.poll() is not None:
        print("Starting server...")
        server = start([], SERVER_CMD, out=os.path.join(BASE, "server.log"))
    if tunnel is None or tunnel.poll() is not None:
        print("Starting tunnel...")
        tunnel = start([], TUNNEL_CMD, out=os.path.join(BASE, "tunnel.log"))
    time.sleep(10)
